/** Distance filter options (meters). null = no limit */
export type DistanceFilterMeters = number | null;

export const DISTANCE_OPTIONS: { label: string; value: DistanceFilterMeters }[] = [
  { label: '全部', value: null },
  { label: '500m', value: 500 },
  { label: '1km', value: 1000 },
  { label: '3km', value: 3000 },
  { label: '5km', value: 5000 },
];

export function filterByDistance<T extends { distance_meters: number | null }>(
  items: T[],
  maxMeters: DistanceFilterMeters
): T[] {
  if (maxMeters == null) return items;
  return items.filter(
    (d) => d.distance_meters != null && d.distance_meters <= maxMeters
  );
}
