import AsyncStorage from '@react-native-async-storage/async-storage';
import { Platform } from 'react-native';

const STORAGE_KEY = 'nearby_deals_device_id';

/** In-memory cache so we don't hit storage on every call */
let cachedId: string | null = null;
let inflight: Promise<string> | null = null;

function generateId(): string {
  const rand =
    typeof crypto !== 'undefined' && 'randomUUID' in crypto
      ? crypto.randomUUID()
      : `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 12)}`;
  return `device-${rand}`;
}

/**
 * Read existing id from AsyncStorage, with a one-time migrate from
 * localStorage on web (legacy getDeviceId).
 */
async function readFromStorage(): Promise<string | null> {
  try {
    const fromAsync = await AsyncStorage.getItem(STORAGE_KEY);
    if (fromAsync) return fromAsync;
  } catch {
    // ignore
  }

  // Web: migrate from previous localStorage key if present
  if (Platform.OS === 'web' && typeof localStorage !== 'undefined') {
    try {
      const legacy = localStorage.getItem(STORAGE_KEY);
      if (legacy) {
        await AsyncStorage.setItem(STORAGE_KEY, legacy);
        return legacy;
      }
    } catch {
      // ignore
    }
  }

  return null;
}

/**
 * Stable anonymous device id. Same value across app restarts on this install.
 * Safe to call many times; result is cached in memory after first resolve.
 */
export async function getOrCreateDeviceId(): Promise<string> {
  if (cachedId) return cachedId;
  if (inflight) return inflight;

  inflight = (async () => {
    let id = await readFromStorage();
    if (!id) {
      id = generateId();
      try {
        await AsyncStorage.setItem(STORAGE_KEY, id);
      } catch {
        // still use in-memory id this session
      }
      // keep web localStorage in sync for older code paths
      if (Platform.OS === 'web' && typeof localStorage !== 'undefined') {
        try {
          localStorage.setItem(STORAGE_KEY, id);
        } catch {
          // ignore
        }
      }
    }
    cachedId = id;
    inflight = null;
    return id;
  })();

  return inflight;
}

/** Synchronous access only after getOrCreateDeviceId has resolved at least once */
export function getCachedDeviceId(): string | null {
  return cachedId;
}

/** Clear local device id (does not delete remote favorites). Next call creates a new id. */
export async function resetDeviceId(): Promise<string> {
  cachedId = null;
  inflight = null;
  try {
    await AsyncStorage.removeItem(STORAGE_KEY);
  } catch {
    // ignore
  }
  if (Platform.OS === 'web' && typeof localStorage !== 'undefined') {
    try {
      localStorage.removeItem(STORAGE_KEY);
    } catch {
      // ignore
    }
  }
  return getOrCreateDeviceId();
}
