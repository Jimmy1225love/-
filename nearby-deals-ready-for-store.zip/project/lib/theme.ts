export const lightTheme = {
  primary: '#2563EB',
  primaryDark: '#1D4ED8',
  primaryLight: '#DBEAFE',
  secondary: '#0EA5E9',
  accent: '#F59E0B',
  success: '#059669',
  warning: '#D97706',
  error: '#DC2626',
  errorLight: '#FEE2E2',
  warningLight: '#FEF3C7',
  bg: '#F8FAFC',
  cardBg: '#FFFFFF',
  textPrimary: '#0F172A',
  textSecondary: '#64748B',
  textTertiary: '#94A3B8',
  border: '#E2E8F0',
  borderLight: '#F1F5F9',
  shadow: 'rgba(15, 23, 42, 0.08)',
  shadowStrong: 'rgba(15, 23, 42, 0.12)',
};

export const darkTheme: typeof lightTheme = {
  primary: '#3B82F6',
  primaryDark: '#2563EB',
  primaryLight: '#1E3A5F',
  secondary: '#38BDF8',
  accent: '#FBBF24',
  success: '#34D399',
  warning: '#FBBF24',
  error: '#F87171',
  errorLight: '#7F1D1D',
  warningLight: '#78350F',
  bg: '#0F172A',
  cardBg: '#1E293B',
  textPrimary: '#F8FAFC',
  textSecondary: '#94A3B8',
  textTertiary: '#64748B',
  border: '#334155',
  borderLight: '#1E293B',
  shadow: 'rgba(0, 0, 0, 0.3)',
  shadowStrong: 'rgba(0, 0, 0, 0.5)',
};

/** Default light theme — prefer useSettings().theme for dark-mode support */
export const theme = lightTheme;

export type Theme = typeof lightTheme;

export function getTheme(darkMode: boolean): Theme {
  return darkMode ? darkTheme : lightTheme;
}
