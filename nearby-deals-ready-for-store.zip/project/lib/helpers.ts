export function formatPrice(price: number | null): string {
  if (price === null || price === undefined) return '';
  return `$${Math.round(price)}`;
}

export function formatDistance(meters: number | null): string {
  if (meters === null || meters === undefined) return '';
  if (meters < 1000) return `${Math.round(meters)}m`;
  return `${(meters / 1000).toFixed(1)}km`;
}

/** Haversine formula — returns distance in meters between two lat/lng points */
export function calculateDistanceMeters(
  lat1: number,
  lon1: number,
  lat2: number,
  lon2: number
): number {
  const R = 6371000; // Earth radius in meters
  const toRad = (deg: number) => (deg * Math.PI) / 180;
  const dLat = toRad(lat2 - lat1);
  const dLon = toRad(lon2 - lon1);
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(toRad(lat1)) * Math.cos(toRad(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

export function daysUntil(dateStr: string | null): number | null {
  if (!dateStr) return null;
  const target = new Date(dateStr);
  const now = new Date();
  now.setHours(0, 0, 0, 0);
  target.setHours(0, 0, 0, 0);
  return Math.round((target.getTime() - now.getTime()) / (1000 * 60 * 60 * 24));
}

/** Local calendar date as YYYY-MM-DD (for Supabase date filters) */
export function todayDateString(): string {
  const now = new Date();
  const y = now.getFullYear();
  const m = String(now.getMonth() + 1).padStart(2, '0');
  const d = String(now.getDate()).padStart(2, '0');
  return `${y}-${m}-${d}`;
}

/**
 * Active if no end_date, or end_date is today or in the future.
 * start_date in the future is still shown (upcoming deals).
 */
export function isDealActive(deal: { end_date?: string | null }): boolean {
  if (!deal.end_date) return true;
  const days = daysUntil(deal.end_date);
  return days === null || days >= 0;
}

export function urgencyLabel(dateStr: string | null): { label: string; color: string } | null {
  const days = daysUntil(dateStr);
  if (days === null) return null;
  if (days < 0) return { label: '已過期', color: '#9CA3AF' };
  if (days === 0) return { label: '今天截止', color: '#DC2626' };
  if (days === 1) return { label: '明天截止', color: '#EA580C' };
  if (days <= 3) return { label: `還剩${days}天`, color: '#D97706' };
  return { label: `還剩${days}天`, color: '#059669' };
}

/** @deprecated Prefer getOrCreateDeviceId / useDeviceId from '@/lib/deviceId' */
export { getCachedDeviceId as getDeviceId } from '@/lib/deviceId';

