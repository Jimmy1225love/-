import { useState, useMemo, useCallback, useRef, useEffect } from 'react';
import {
  StyleSheet,
  Text,
  View,
  Pressable,
  Platform,
  ScrollView,
} from 'react-native';
import { router } from 'expo-router';
import MapView, {
  PROVIDER_DEFAULT,
  type Region,
} from 'react-native-maps';
import { MapPin, LocateFixed } from 'lucide-react-native';
import { theme } from '@/lib/theme';
import { useDeals, useFavorites } from '@/hooks/useDeals';
import { useUserLocation } from '@/hooks/useUserLocation';
import { useSettings, NEARBY_ONLY_METERS } from '@/hooks/useSettings';
import { DealCard } from '@/components/DealCard';
import { DealMarker } from '@/components/DealMarker';
import { LoadingState, ErrorState } from '@/components/States';
import {
  DISTANCE_OPTIONS,
  filterByDistance,
  type DistanceFilterMeters,
} from '@/lib/distanceFilter';
import type { Deal } from '@/types/deals';

/** Hong Kong default center when no location / deals */
const HK_CENTER: Region = {
  latitude: 22.3193,
  longitude: 114.1694,
  latitudeDelta: 0.08,
  longitudeDelta: 0.08,
};

function regionFromPoints(
  points: { latitude: number; longitude: number }[]
): Region {
  if (points.length === 0) return HK_CENTER;

  const lats = points.map((p) => p.latitude);
  const lngs = points.map((p) => p.longitude);
  const minLat = Math.min(...lats);
  const maxLat = Math.max(...lats);
  const minLng = Math.min(...lngs);
  const maxLng = Math.max(...lngs);

  const midLat = (minLat + maxLat) / 2;
  const midLng = (minLng + maxLng) / 2;
  const latDelta = Math.max((maxLat - minLat) * 1.6, 0.02);
  const lngDelta = Math.max((maxLng - minLng) * 1.6, 0.02);

  return {
    latitude: midLat,
    longitude: midLng,
    latitudeDelta: latDelta,
    longitudeDelta: lngDelta,
  };
}

export default function MapScreen() {
  const mapRef = useRef<MapView>(null);
  const { coords, hasLocation, refreshing: locationRefreshing, refresh: refreshLocation } = useUserLocation();
  const { deals, loading, error, reload } = useDeals(coords);
  const { isFavorite, toggleFavorite } = useFavorites();
  const { nearbyOnly } = useSettings();
  const [selectedDeal, setSelectedDeal] = useState<Deal | null>(null);
  const [mapReady, setMapReady] = useState(false);
  const [distanceFilter, setDistanceFilter] = useState<DistanceFilterMeters>(null);

  const effectiveDistance = useMemo((): DistanceFilterMeters => {
    if (nearbyOnly) {
      if (distanceFilter == null) return NEARBY_ONLY_METERS;
      return Math.min(distanceFilter, NEARBY_ONLY_METERS);
    }
    return distanceFilter;
  }, [nearbyOnly, distanceFilter]);

  const dealsWithLocation = useMemo(() => {
    const withLoc = deals.filter((d) => d.latitude != null && d.longitude != null);
    return filterByDistance(withLoc, effectiveDistance);
  }, [deals, effectiveDistance]);

  const initialRegion = useMemo(() => {
    const points: { latitude: number; longitude: number }[] = dealsWithLocation.map(
      (d) => ({ latitude: d.latitude!, longitude: d.longitude! })
    );
    if (coords) points.push(coords);
    return regionFromPoints(points);
  }, [dealsWithLocation, coords]);

  useEffect(() => {
    if (!mapReady || !mapRef.current) return;
    const points: { latitude: number; longitude: number }[] = dealsWithLocation.map(
      (d) => ({ latitude: d.latitude!, longitude: d.longitude! })
    );
    if (coords) points.push(coords);
    if (points.length === 0) return;

    if (points.length === 1) {
      mapRef.current.animateToRegion(
        {
          ...points[0],
          latitudeDelta: 0.03,
          longitudeDelta: 0.03,
        },
        400
      );
      return;
    }

    mapRef.current.fitToCoordinates(points, {
      edgePadding: { top: 80, right: 40, bottom: selectedDeal ? 220 : 80, left: 40 },
      animated: true,
    });
  }, [mapReady, dealsWithLocation, coords, selectedDeal]);

  // Clear selection if filtered out
  useEffect(() => {
    if (selectedDeal && !dealsWithLocation.some((d) => d.id === selectedDeal.id)) {
      setSelectedDeal(null);
    }
  }, [dealsWithLocation, selectedDeal]);

  const handleDealPress = useCallback((deal: Deal) => {
    router.push(`/deal/${deal.id}`);
  }, []);

  const handleMarkerPress = useCallback((deal: Deal) => {
    setSelectedDeal(deal);
    if (mapRef.current && deal.latitude != null && deal.longitude != null) {
      mapRef.current.animateToRegion(
        {
          latitude: deal.latitude,
          longitude: deal.longitude,
          latitudeDelta: 0.02,
          longitudeDelta: 0.02,
        },
        350
      );
    }
  }, []);

  const goToUser = useCallback(async () => {
    const next = await refreshLocation();
    const target = next ?? coords;
    if (target && mapRef.current) {
      mapRef.current.animateToRegion(
        {
          latitude: target.latitude,
          longitude: target.longitude,
          latitudeDelta: 0.025,
          longitudeDelta: 0.025,
        },
        400
      );
    }
  }, [coords, refreshLocation]);

  if (loading) return <LoadingState message="載入地圖資料..." />;
  if (error) return <ErrorState message={error} onRetry={reload} />;

  if (Platform.OS === 'web') {
    return (
      <View style={styles.container}>
        <View style={styles.header}>
          <Text style={styles.appTitle}>優惠地圖</Text>
          <Text style={styles.appSubtitle}>
            {dealsWithLocation.length} 個優惠據點
            {locationRefreshing ? ' · 重新定位中…' : hasLocation ? ' · 已依你的位置計算距離' : ' · 未取得位置 · 點定位按鈕重試'}
          </Text>
        </View>
        <View style={styles.webFallback}>
          <MapPin size={40} color={theme.primary} strokeWidth={2} />
          <Text style={styles.webFallbackTitle}>地圖需在手機 App 中使用</Text>
          <Text style={styles.webFallbackSub}>
            Web 版暫不支援原生地圖，請用 iOS / Android 開啟以查看完整地圖與標記。
          </Text>
          {dealsWithLocation.length > 0 && (
            <View style={styles.webList}>
              {dealsWithLocation.slice(0, 8).map((deal) => (
                <Pressable
                  key={deal.id}
                  style={styles.webListItem}
                  onPress={() => handleDealPress(deal)}
                >
                  <Text style={styles.webListStore}>{deal.store_name}</Text>
                  <Text style={styles.webListTitle} numberOfLines={1}>
                    {deal.title}
                  </Text>
                </Pressable>
              ))}
            </View>
          )}
        </View>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.appTitle}>優惠地圖</Text>
        <Text style={styles.appSubtitle}>
          {dealsWithLocation.length} 個優惠據點
          {locationRefreshing ? ' · 重新定位中…' : hasLocation ? ' · 已依你的位置計算距離' : ' · 未取得位置 · 點定位按鈕重試'}
        </Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={styles.distanceRow}
        >
          {DISTANCE_OPTIONS.map((opt) => {
            const active = distanceFilter === opt.value;
            return (
              <Pressable
                key={opt.label}
                style={[styles.distanceChip, active && styles.distanceChipActive]}
                onPress={() => setDistanceFilter(opt.value)}
              >
                <Text
                  style={[styles.distanceChipText, active && styles.distanceChipTextActive]}
                >
                  {opt.label}
                </Text>
              </Pressable>
            );
          })}
        </ScrollView>
      </View>

      <View style={styles.mapWrap}>
        <MapView
          ref={mapRef}
          style={styles.map}
          provider={PROVIDER_DEFAULT}
          initialRegion={initialRegion}
          showsUserLocation={hasLocation}
          showsMyLocationButton={false}
          showsCompass
          onMapReady={() => setMapReady(true)}
          onPress={() => setSelectedDeal(null)}
        >
          {dealsWithLocation.map((deal) => (
            <DealMarker
              key={deal.id}
              deal={deal}
              selected={selectedDeal?.id === deal.id}
              onPress={handleMarkerPress}
            />
          ))}
        </MapView>

        {dealsWithLocation.length === 0 && (
          <View style={styles.emptyOverlay} pointerEvents="none">
            <Text style={styles.emptyOverlayText}>
              {distanceFilter != null
                ? `此範圍內沒有優惠，試試擴大距離`
                : '目前沒有附帶位置的優惠'}
            </Text>
          </View>
        )}

        <Pressable style={styles.locateBtn} onPress={goToUser} hitSlop={8}>
          <LocateFixed size={22} color={theme.primary} strokeWidth={2.5} />
        </Pressable>

        {selectedDeal && (
          <View style={styles.selectedCardWrap}>
            <DealCard
              deal={selectedDeal}
              isFavorite={isFavorite(selectedDeal.id)}
              onToggleFavorite={toggleFavorite}
              onPress={handleDealPress}
              compact
            />
          </View>
        )}
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.bg,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 10,
    backgroundColor: theme.cardBg,
    borderBottomWidth: 1,
    borderBottomColor: theme.borderLight,
    zIndex: 2,
  },
  appTitle: {
    fontSize: 28,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
    letterSpacing: -0.5,
  },
  appSubtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
    marginTop: 4,
    marginBottom: 10,
  },
  distanceRow: {
    gap: 8,
    paddingRight: 8,
  },
  distanceChip: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: theme.bg,
    borderWidth: 1,
    borderColor: theme.border,
  },
  distanceChipActive: {
    backgroundColor: theme.secondary,
    borderColor: theme.secondary,
  },
  distanceChipText: {
    fontSize: 12,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  distanceChipTextActive: {
    color: '#FFFFFF',
  },
  mapWrap: {
    flex: 1,
    position: 'relative',
  },
  map: {
    ...StyleSheet.absoluteFillObject,
  },
  locateBtn: {
    position: 'absolute',
    right: 16,
    top: 16,
    width: 44,
    height: 44,
    borderRadius: 22,
    backgroundColor: theme.cardBg,
    alignItems: 'center',
    justifyContent: 'center',
    shadowColor: theme.shadowStrong,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 6,
    elevation: 4,
    borderWidth: 1,
    borderColor: theme.borderLight,
  },
  selectedCardWrap: {
    position: 'absolute',
    left: 12,
    right: 12,
    bottom: 16,
  },
  emptyOverlay: {
    position: 'absolute',
    top: 24,
    left: 24,
    right: 24,
    alignItems: 'center',
  },
  emptyOverlayText: {
    backgroundColor: theme.cardBg,
    paddingHorizontal: 14,
    paddingVertical: 8,
    borderRadius: 20,
    overflow: 'hidden',
    fontSize: 13,
    fontFamily: 'NotoSansTC-Medium',
    color: theme.textSecondary,
    borderWidth: 1,
    borderColor: theme.borderLight,
  },
  webFallback: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
    gap: 12,
  },
  webFallbackTitle: {
    fontSize: 18,
    fontFamily: 'NotoSansTC-SemiBold',
    fontWeight: '600',
    color: theme.textPrimary,
    textAlign: 'center',
  },
  webFallbackSub: {
    fontSize: 14,
    fontFamily: 'NotoSansTC-Regular',
    color: theme.textSecondary,
    textAlign: 'center',
    lineHeight: 22,
  },
  webList: {
    width: '100%',
    marginTop: 20,
    gap: 8,
  },
  webListItem: {
    backgroundColor: theme.cardBg,
    borderRadius: 12,
    padding: 14,
    borderWidth: 1,
    borderColor: theme.borderLight,
  },
  webListStore: {
    fontSize: 12,
    color: theme.textTertiary,
    fontFamily: 'NotoSansTC-Regular',
  },
  webListTitle: {
    fontSize: 15,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-Medium',
    marginTop: 2,
  },
});
