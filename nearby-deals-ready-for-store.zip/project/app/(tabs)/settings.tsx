import { useCallback, useMemo } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Pressable,
  Switch,
  Alert,
  Platform,
  Linking,
} from 'react-native';
import { router } from 'expo-router';
import {
  Bell,
  MapPin,
  Info,
  Moon,
  Globe,
  Trash2,
  ChevronRight,
  Flame,
  Heart,
  Download,
  Shield,
  FileText,
} from 'lucide-react-native';
import type { Theme } from '@/lib/theme';
import { useDeals } from '@/hooks/useDeals';
import { useFavorites, useFavoriteDeals } from '@/hooks/useFavorites';
import { useSettings, useLabels } from '@/hooks/useSettings';

export default function SettingsScreen() {
  const { deals } = useDeals();
  const { deals: favDeals, reload: reloadFavs } = useFavoriteDeals();
  const { clearAllFavorites, favoriteIds } = useFavorites();
  const {
    theme,
    notificationsEnabled,
    setNotificationsEnabled,
    nearbyOnly,
    setNearbyOnly,
    darkMode,
    setDarkMode,
    language,
    toggleLanguage,
  } = useSettings();
  const t = useLabels();
  const styles = useMemo(() => createStyles(theme), [theme]);

  const favCount = favoriteIds.size || favDeals.length;

  const clearAndReload = useCallback(async () => {
    await clearAllFavorites();
    await reloadFavs();
  }, [clearAllFavorites, reloadFavs]);

  const handleClearFavorites = useCallback(() => {
    if (favCount === 0) return;

    if (Platform.OS === 'web') {
      const ok = window.confirm(
        language === 'en'
          ? `Clear all ${favCount} favorites? This cannot be undone.`
          : `確定要清除所有 ${favCount} 個收藏？此操作無法復原。`
      );
      if (!ok) return;
      clearAndReload();
    } else {
      Alert.alert(
        language === 'en' ? 'Clear favorites' : '清除收藏',
        language === 'en'
          ? `Clear all ${favCount} favorites?`
          : `確定要清除所有 ${favCount} 個收藏？`,
        [
          { text: language === 'en' ? 'Cancel' : '取消', style: 'cancel' },
          {
            text: language === 'en' ? 'Clear' : '確定清除',
            style: 'destructive',
            onPress: clearAndReload,
          },
        ]
      );
    }
  }, [favCount, clearAndReload, language]);

  return (
    <ScrollView style={styles.container} showsVerticalScrollIndicator={false}>
      <View style={styles.header}>
        <Text style={styles.appTitle}>{t.settings}</Text>
        <Text style={styles.appSubtitle}>{t.settingsSubtitle}</Text>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t.notifications}</Text>
        <View style={styles.card}>
          <View style={styles.settingRow}>
            <View style={styles.settingIconWrap}>
              <Bell size={18} color={theme.primary} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>{t.pushDeals}</Text>
              <Text style={styles.settingDesc}>{t.pushDealsDesc}</Text>
            </View>
            <Switch
              value={notificationsEnabled}
              onValueChange={setNotificationsEnabled}
              trackColor={{ false: theme.border, true: theme.primary }}
              thumbColor="#FFFFFF"
            />
          </View>

          <View style={styles.divider} />

          <View style={styles.settingRow}>
            <View style={styles.settingIconWrap}>
              <MapPin size={18} color={theme.success} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>{t.nearbyOnly}</Text>
              <Text style={styles.settingDesc}>{t.nearbyOnlyDesc}</Text>
            </View>
            <Switch
              value={nearbyOnly}
              onValueChange={setNearbyOnly}
              trackColor={{ false: theme.border, true: theme.primary }}
              thumbColor="#FFFFFF"
            />
          </View>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t.appearance}</Text>
        <View style={styles.card}>
          <View style={styles.settingRow}>
            <View style={styles.settingIconWrap}>
              <Moon size={18} color={theme.textSecondary} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>{t.darkMode}</Text>
              <Text style={styles.settingDesc}>{t.darkModeDesc}</Text>
            </View>
            <Switch
              value={darkMode}
              onValueChange={setDarkMode}
              trackColor={{ false: theme.border, true: theme.primary }}
              thumbColor="#FFFFFF"
            />
          </View>

          <View style={styles.divider} />

          <Pressable style={styles.settingRow} onPress={toggleLanguage}>
            <View style={styles.settingIconWrap}>
              <Globe size={18} color={theme.secondary} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>{t.language}</Text>
              <Text style={styles.settingDesc}>
                {language === 'zh' ? '繁體中文' : 'English'}
              </Text>
            </View>
            <ChevronRight size={18} color={theme.textTertiary} strokeWidth={2.5} />
          </Pressable>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t.data}</Text>
        <View style={styles.card}>
          <Pressable
            style={styles.settingRow}
            onPress={() => router.push('/favorites')}
          >
            <View style={styles.settingIconWrap}>
              <Heart size={18} color={theme.error} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>{t.favorites}</Text>
              <Text style={styles.settingDesc}>
                {language === 'en'
                  ? `${favCount} saved deals`
                  : `${favCount} 個已收藏的優惠`}
              </Text>
            </View>
            <ChevronRight size={18} color={theme.textTertiary} strokeWidth={2.5} />
          </Pressable>

          <View style={styles.divider} />

          <Pressable
            style={({ pressed }) => [
              styles.settingRow,
              pressed && styles.dangerRow,
              favCount === 0 && styles.disabledRow,
            ]}
            onPress={handleClearFavorites}
            disabled={favCount === 0}
          >
            <View style={[styles.settingIconWrap, styles.dangerIconWrap]}>
              <Trash2 size={18} color={theme.error} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={[styles.settingLabel, styles.dangerText]}>
                {t.clearFavorites}
              </Text>
              <Text style={styles.settingDesc}>{t.clearFavoritesDesc}</Text>
            </View>
            <ChevronRight size={18} color={theme.textTertiary} strokeWidth={2.5} />
          </Pressable>
        </View>
      </View>

      <View style={styles.section}>
        <Text style={styles.sectionTitle}>{t.about}</Text>
        <View style={styles.card}>
          <View style={styles.settingRow}>
            <View style={styles.settingIconWrap}>
              <Flame size={18} color={theme.accent} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>{t.version}</Text>
              <Text style={styles.settingDesc}>1.0.0</Text>
            </View>
          </View>

          <View style={styles.divider} />

          <View style={styles.settingRow}>
            <View style={styles.settingIconWrap}>
              <Download size={18} color={theme.success} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>{t.dealCount}</Text>
              <Text style={styles.settingDesc}>
                {deals.length} {t.dealCountSuffix}
              </Text>
            </View>
          </View>

          <View style={styles.divider} />

          <View style={styles.settingRow}>
            <View style={styles.settingIconWrap}>
              <Info size={18} color={theme.textSecondary} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>{t.aboutApp}</Text>
              <Text style={styles.settingDesc}>{t.aboutAppDesc}</Text>
            </View>
          </View>

          <View style={styles.divider} />

          <Pressable
            style={styles.settingRow}
            onPress={() =>
              Linking.openURL(
                'https://yourdomain.com/privacy'
              ).catch(() =>
                Alert.alert(
                  language === 'en' ? 'Unable to open' : '無法開啟',
                  language === 'en'
                    ? 'Please set privacyPolicyUrl in app config.'
                    : '請先在設定中填寫隱私權政策網址。'
                )
              )
            }
          >
            <View style={styles.settingIconWrap}>
              <Shield size={18} color={theme.primary} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>
                {language === 'en' ? 'Privacy Policy' : '隱私權政策'}
              </Text>
              <Text style={styles.settingDesc}>
                {language === 'en' ? 'How we handle your data' : '我們如何處理你的資料'}
              </Text>
            </View>
            <ChevronRight size={18} color={theme.textTertiary} strokeWidth={2.5} />
          </Pressable>

          <View style={styles.divider} />

          <Pressable
            style={styles.settingRow}
            onPress={() =>
              Linking.openURL('https://yourdomain.com/terms').catch(() =>
                Alert.alert(
                  language === 'en' ? 'Unable to open' : '無法開啟',
                  language === 'en'
                    ? 'Please set termsUrl in app config.'
                    : '請先在設定中填寫服務條款網址。'
                )
              )
            }
          >
            <View style={styles.settingIconWrap}>
              <FileText size={18} color={theme.secondary} strokeWidth={2.5} />
            </View>
            <View style={styles.settingContent}>
              <Text style={styles.settingLabel}>
                {language === 'en' ? 'Terms of Service' : '服務條款'}
              </Text>
              <Text style={styles.settingDesc}>
                {language === 'en' ? 'Rules for using this app' : '使用本 App 的規則'}
              </Text>
            </View>
            <ChevronRight size={18} color={theme.textTertiary} strokeWidth={2.5} />
          </Pressable>
        </View>
      </View>

      <View style={styles.footer}>
        <Text style={styles.footerText}>{t.appName}</Text>
        <Text style={styles.footerSubtext}>v1.0.0 - Made with care</Text>
      </View>

      <View style={{ height: 24 }} />
    </ScrollView>
  );
}

function createStyles(theme: Theme) {
  return StyleSheet.create({
    container: {
      flex: 1,
      backgroundColor: theme.bg,
    },
    header: {
      paddingHorizontal: 20,
      paddingTop: 56,
      paddingBottom: 16,
      backgroundColor: theme.cardBg,
      borderBottomWidth: 1,
      borderBottomColor: theme.borderLight,
    },
    appTitle: {
      fontSize: 28,
      color: theme.textPrimary,
      fontFamily: 'NotoSansTC-Bold',
      fontWeight: '700',
      letterSpacing: -0.5,
    },
    appSubtitle: {
      fontSize: 14,
      color: theme.textSecondary,
      fontFamily: 'NotoSansTC-Regular',
      marginTop: 4,
    },
    section: {
      paddingHorizontal: 20,
      paddingTop: 24,
    },
    sectionTitle: {
      fontSize: 13,
      color: theme.textTertiary,
      fontFamily: 'NotoSansTC-Medium',
      fontWeight: '500',
      marginBottom: 10,
      textTransform: 'uppercase',
      letterSpacing: 0.5,
    },
    card: {
      backgroundColor: theme.cardBg,
      borderRadius: 16,
      overflow: 'hidden',
      borderWidth: 1,
      borderColor: theme.borderLight,
    },
    settingRow: {
      flexDirection: 'row',
      alignItems: 'center',
      paddingHorizontal: 16,
      paddingVertical: 14,
      gap: 12,
    },
    dangerRow: {
      backgroundColor: theme.errorLight,
    },
    disabledRow: {
      opacity: 0.4,
    },
    settingIconWrap: {
      width: 36,
      height: 36,
      borderRadius: 10,
      backgroundColor: theme.bg,
      alignItems: 'center',
      justifyContent: 'center',
    },
    dangerIconWrap: {
      backgroundColor: theme.errorLight,
    },
    settingContent: {
      flex: 1,
    },
    settingLabel: {
      fontSize: 15,
      color: theme.textPrimary,
      fontFamily: 'NotoSansTC-Medium',
      fontWeight: '500',
      marginBottom: 2,
    },
    dangerText: {
      color: theme.error,
    },
    settingDesc: {
      fontSize: 13,
      color: theme.textSecondary,
      fontFamily: 'NotoSansTC-Regular',
    },
    divider: {
      height: 1,
      backgroundColor: theme.borderLight,
      marginLeft: 64,
    },
    footer: {
      alignItems: 'center',
      paddingTop: 32,
      paddingBottom: 8,
    },
    footerText: {
      fontSize: 14,
      color: theme.textTertiary,
      fontFamily: 'NotoSansTC-Medium',
      fontWeight: '500',
    },
    footerSubtext: {
      fontSize: 12,
      color: theme.textTertiary,
      fontFamily: 'NotoSansTC-Regular',
      marginTop: 4,
    },
  });
}
