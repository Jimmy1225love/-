import { useState, useMemo, useCallback } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Pressable,
  RefreshControl,
  SectionList,
  TextInput,
} from 'react-native';
import { router } from 'expo-router';
import { Search, SlidersHorizontal, Flame, TrendingUp, MapPin, X } from 'lucide-react-native';
import { theme } from '@/lib/theme';
import { useDeals, useFavorites } from '@/hooks/useDeals';
import { useCategories } from '@/hooks/useCategories';
import { useUserLocation } from '@/hooks/useUserLocation';
import { useSettings, NEARBY_ONLY_METERS } from '@/hooks/useSettings';
import { DealCard } from '@/components/DealCard';
import { LoadingState, ErrorState, EmptyState } from '@/components/States';
import {
  DISTANCE_OPTIONS,
  filterByDistance,
  type DistanceFilterMeters,
} from '@/lib/distanceFilter';
import type { Deal } from '@/types/deals';

type SortMode = 'distance' | 'discount' | 'expiring';

export default function DealsScreen() {
  const {
    coords,
    status: locationStatus,
    loading: locationLoading,
    refreshing: locationRefreshing,
    refresh: refreshLocation,
    hasLocation,
  } = useUserLocation();
  const { deals, loading, error, reload } = useDeals(coords);
  const { categories: allCategories } = useCategories();
  const { isFavorite, toggleFavorite } = useFavorites();
  const { nearbyOnly } = useSettings();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeCategory, setActiveCategory] = useState<string>('all');
  const [sortMode, setSortMode] = useState<SortMode>('distance');
  const [showSortMenu, setShowSortMenu] = useState(false);
  const [refreshing, setRefreshing] = useState(false);
  const [distanceFilter, setDistanceFilter] = useState<DistanceFilterMeters>(null);

  /** When "nearby only" is on in Settings, force 1km cap (stricter of the two wins) */
  const effectiveDistance = useMemo((): DistanceFilterMeters => {
    if (nearbyOnly) {
      if (distanceFilter == null) return NEARBY_ONLY_METERS;
      return Math.min(distanceFilter, NEARBY_ONLY_METERS);
    }
    return distanceFilter;
  }, [nearbyOnly, distanceFilter]);

  /** Category chips: always from categories table + deal count (after distance filter only) */
  const categoryChips = useMemo(() => {
    const distanceFiltered = filterByDistance(deals, effectiveDistance);
    const countById = new Map<string, number>();
    distanceFiltered.forEach((d) => {
      if (d.category_id) {
        countById.set(d.category_id, (countById.get(d.category_id) ?? 0) + 1);
      }
    });

    // Prefer DB categories; fall back to whatever appears on deals
    if (allCategories.length > 0) {
      return allCategories.map((c) => ({
        id: c.id,
        name: c.name,
        color: c.color || theme.primary,
        count: countById.get(c.id) ?? 0,
      }));
    }

    const fromDeals = new Map<string, { name: string; color: string }>();
    deals.forEach((d) => {
      if (d.categories) {
        fromDeals.set(d.categories.id, {
          name: d.categories.name,
          color: d.categories.color || theme.primary,
        });
      }
    });
    return Array.from(fromDeals.entries()).map(([id, meta]) => ({
      id,
      name: meta.name,
      color: meta.color,
      count: countById.get(id) ?? 0,
    }));
  }, [deals, allCategories, effectiveDistance]);

  const filteredDeals = useMemo(() => {
    let result = filterByDistance(deals, effectiveDistance);

    if (activeCategory !== 'all') {
      result = result.filter(
        (d) => d.category_id === activeCategory || d.categories?.id === activeCategory
      );
    }

    if (searchQuery.trim()) {
      const q = searchQuery.trim().toLowerCase();
      result = result.filter(
        (d) =>
          d.title.toLowerCase().includes(q) ||
          d.store_name.toLowerCase().includes(q) ||
          (d.tags || []).some((t) => t.toLowerCase().includes(q))
      );
    }

    const sorted = [...result];
    if (sortMode === 'distance') {
      sorted.sort((a, b) => (a.distance_meters ?? 99999) - (b.distance_meters ?? 99999));
    } else if (sortMode === 'discount') {
      sorted.sort((a, b) => (b.discount_percentage ?? 0) - (a.discount_percentage ?? 0));
    } else if (sortMode === 'expiring') {
      sorted.sort((a, b) => {
        const aTime = a.end_date ? new Date(a.end_date).getTime() : Infinity;
        const bTime = b.end_date ? new Date(b.end_date).getTime() : Infinity;
        return aTime - bTime;
      });
    }

    return sorted;
  }, [deals, activeCategory, searchQuery, sortMode, effectiveDistance]);

  const featuredDeals = useMemo(
    () => filteredDeals.filter((d) => d.is_featured).slice(0, 5),
    [filteredDeals]
  );
  const regularDeals = useMemo(
    () => filteredDeals.filter((d) => !d.is_featured),
    [filteredDeals]
  );

  const sections = useMemo(() => {
    const secs: { title: string; data: Deal[]; type: 'featured' | 'regular' }[] = [];
    if (featuredDeals.length > 0) {
      secs.push({ title: '精選優惠', data: featuredDeals, type: 'featured' });
    }
    if (regularDeals.length > 0) {
      secs.push({ title: '附近優惠', data: regularDeals, type: 'regular' });
    }
    return secs;
  }, [featuredDeals, regularDeals]);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await Promise.all([reload(), refreshLocation()]);
    setRefreshing(false);
  }, [reload, refreshLocation]);

  const totalInDistance = useMemo(
    () => filterByDistance(deals, effectiveDistance).length,
    [deals, effectiveDistance]
  );

  const handleDealPress = useCallback((deal: Deal) => {
    router.push(`/deal/${deal.id}`);
  }, []);

  const sortLabels: Record<SortMode, string> = {
    distance: '依距離',
    discount: '依折扣',
    expiring: '依到期日',
  };

  if (loading) return <LoadingState message="正在尋找附近優惠..." />;
  if (error) return <ErrorState message={error} onRetry={reload} />;

  const locationHint =
    locationStatus === 'denied'
      ? '未授權位置 · 點此重試'
      : locationStatus === 'unavailable' || locationStatus === 'error'
        ? '無法取得位置 · 點此重試'
        : locationLoading || locationRefreshing
          ? '重新定位中…'
          : hasLocation
            ? '已依你的位置計算距離 · 點此更新'
            : null;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.appTitle}>附近優惠</Text>
        <Text style={styles.appSubtitle}>找到你周圍的超市與餐廳好康</Text>
        {locationHint && (
          <Pressable style={styles.locationHint} onPress={refreshLocation}>
            <MapPin size={12} color={hasLocation ? theme.success : theme.warning} strokeWidth={2.5} />
            <Text
              style={[
                styles.locationHintText,
                { color: hasLocation ? theme.success : theme.warning },
              ]}
            >
              {locationHint}
            </Text>
          </Pressable>
        )}
      </View>

      <View style={styles.searchRow}>
        <View style={styles.searchBox}>
          <Search size={18} color={theme.textTertiary} strokeWidth={2.5} />
          <TextInput
            style={styles.searchInput}
            placeholder="搜尋優惠、店家或標籤"
            placeholderTextColor={theme.textTertiary}
            value={searchQuery}
            onChangeText={setSearchQuery}
            returnKeyType="search"
            autoCapitalize="none"
            autoCorrect={false}
            clearButtonMode="never"
          />
          {searchQuery.length > 0 && (
            <Pressable
              onPress={() => setSearchQuery('')}
              hitSlop={{ top: 8, bottom: 8, left: 8, right: 8 }}
              accessibilityLabel="清除搜尋"
            >
              <X size={16} color={theme.textTertiary} strokeWidth={2.5} />
            </Pressable>
          )}
        </View>
        <Pressable
          style={[styles.sortButton, showSortMenu && styles.sortButtonActive]}
          onPress={() => setShowSortMenu(!showSortMenu)}
        >
          <SlidersHorizontal size={18} color={theme.textSecondary} strokeWidth={2.5} />
          <Text style={styles.sortLabel}>{sortLabels[sortMode]}</Text>
        </Pressable>
      </View>

      {showSortMenu && (
        <View style={styles.sortMenu}>
          {(['distance', 'discount', 'expiring'] as SortMode[]).map((mode) => (
            <Pressable
              key={mode}
              style={[styles.sortMenuItem, sortMode === mode && styles.sortMenuItemActive]}
              onPress={() => {
                setSortMode(mode);
                setShowSortMenu(false);
              }}
            >
              <Text
                style={[
                  styles.sortMenuItemText,
                  sortMode === mode && styles.sortMenuItemTextActive,
                ]}
              >
                {sortLabels[mode]}
              </Text>
            </Pressable>
          ))}
        </View>
      )}

      {/* Distance filter */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.distanceScroll}
        contentContainerStyle={styles.distanceScrollContent}
      >
        {DISTANCE_OPTIONS.map((opt) => {
          const active = distanceFilter === opt.value;
          return (
            <Pressable
              key={opt.label}
              style={[styles.distanceChip, active && styles.distanceChipActive]}
              onPress={() => setDistanceFilter(opt.value)}
            >
              <MapPin
                size={12}
                color={active ? '#FFFFFF' : theme.textSecondary}
                strokeWidth={2.5}
              />
              <Text
                style={[styles.distanceChipText, active && styles.distanceChipTextActive]}
              >
                {opt.label}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      {/* Category filter chips */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={styles.categoryScroll}
        contentContainerStyle={styles.categoryScrollContent}
      >
        <Pressable
          style={[
            styles.categoryChip,
            activeCategory === 'all' && styles.categoryChipActiveAll,
          ]}
          onPress={() => setActiveCategory('all')}
        >
          <Text
            style={[
              styles.categoryChipText,
              activeCategory === 'all' && styles.categoryChipTextActive,
            ]}
          >
            全部
          </Text>
          <View
            style={[
              styles.categoryCount,
              activeCategory === 'all' && styles.categoryCountActive,
            ]}
          >
            <Text
              style={[
                styles.categoryCountText,
                activeCategory === 'all' && styles.categoryCountTextActive,
              ]}
            >
              {totalInDistance}
            </Text>
          </View>
        </Pressable>
        {categoryChips.map((cat) => {
          const isActive = activeCategory === cat.id;
          return (
            <Pressable
              key={cat.id}
              style={[
                styles.categoryChip,
                isActive && {
                  backgroundColor: cat.color,
                  borderColor: cat.color,
                },
              ]}
              onPress={() => setActiveCategory(cat.id)}
            >
              <View
                style={[
                  styles.categoryDot,
                  { backgroundColor: isActive ? '#FFFFFF' : cat.color },
                ]}
              />
              <Text
                style={[
                  styles.categoryChipText,
                  isActive && styles.categoryChipTextActive,
                ]}
              >
                {cat.name}
              </Text>
              <View
                style={[
                  styles.categoryCount,
                  isActive && styles.categoryCountActive,
                ]}
              >
                <Text
                  style={[
                    styles.categoryCountText,
                    isActive && styles.categoryCountTextActive,
                  ]}
                >
                  {cat.count}
                </Text>
              </View>
            </Pressable>
          );
        })}
      </ScrollView>

      {filteredDeals.length === 0 ? (
        <EmptyState
          title={
            searchQuery.trim()
              ? '找不到符合的優惠'
              : activeCategory !== 'all'
                ? '此分類暫時沒有優惠'
                : '目前沒有優惠'
          }
          subtitle={
            searchQuery.trim()
              ? `沒有與「${searchQuery.trim()}」相關的結果，試試其他關鍵字`
              : activeCategory !== 'all'
                ? '點「全部」或換其他分類，也可擴大距離範圍'
                : '試試更換分類或距離範圍'
          }
        />
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(item) => item.id}
          renderSectionHeader={({ section }) => (
            <View style={styles.sectionHeader}>
              {section.type === 'featured' ? (
                <Flame size={16} color={theme.accent} strokeWidth={2.5} />
              ) : (
                <TrendingUp size={16} color={theme.textSecondary} strokeWidth={2.5} />
              )}
              <Text style={styles.sectionTitle}>{section.title}</Text>
              <View style={styles.sectionCount}>
                <Text style={styles.sectionCountText}>{section.data.length}</Text>
              </View>
            </View>
          )}
          renderItem={({ item }) => (
            <DealCard
              deal={item}
              isFavorite={isFavorite(item.id)}
              onToggleFavorite={toggleFavorite}
              onPress={handleDealPress}
            />
          )}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />
          }
          showsVerticalScrollIndicator={false}
          stickySectionHeadersEnabled={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.bg,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 12,
    backgroundColor: theme.cardBg,
  },
  appTitle: {
    fontSize: 28,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
    letterSpacing: -0.5,
  },
  appSubtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
    marginTop: 4,
  },
  locationHint: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    marginTop: 8,
  },
  locationHintText: {
    fontSize: 12,
    fontFamily: 'NotoSansTC-Medium',
  },
  searchRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    paddingHorizontal: 20,
    paddingVertical: 12,
    backgroundColor: theme.cardBg,
    borderBottomWidth: 1,
    borderBottomColor: theme.borderLight,
  },
  searchBox: {
    flex: 1,
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    backgroundColor: theme.bg,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 8,
    borderWidth: 1,
    borderColor: theme.border,
  },
  searchInput: {
    flex: 1,
    fontSize: 14,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-Regular',
    paddingVertical: 4,
    margin: 0,
  },
  sortButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: theme.bg,
    borderRadius: 12,
    paddingHorizontal: 12,
    paddingVertical: 10,
    borderWidth: 1,
    borderColor: theme.border,
  },
  sortButtonActive: {
    borderColor: theme.primary,
    backgroundColor: theme.primaryLight,
  },
  sortLabel: {
    fontSize: 13,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  sortMenu: {
    position: 'absolute',
    top: 118,
    right: 20,
    backgroundColor: theme.cardBg,
    borderRadius: 12,
    padding: 4,
    shadowColor: theme.shadowStrong,
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 1,
    shadowRadius: 12,
    elevation: 8,
    zIndex: 100,
    minWidth: 140,
  },
  sortMenuItem: {
    paddingHorizontal: 16,
    paddingVertical: 10,
    borderRadius: 8,
  },
  sortMenuItemActive: {
    backgroundColor: theme.primaryLight,
  },
  sortMenuItemText: {
    fontSize: 14,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
  },
  sortMenuItemTextActive: {
    color: theme.primary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  distanceScroll: {
    flexGrow: 0,
    backgroundColor: theme.cardBg,
    paddingTop: 4,
  },
  distanceScrollContent: {
    paddingHorizontal: 20,
    paddingBottom: 6,
    gap: 8,
  },
  distanceChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 16,
    backgroundColor: theme.bg,
    borderWidth: 1,
    borderColor: theme.border,
  },
  distanceChipActive: {
    backgroundColor: theme.secondary,
    borderColor: theme.secondary,
  },
  distanceChipText: {
    fontSize: 12,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  distanceChipTextActive: {
    color: '#FFFFFF',
  },
  categoryScroll: {
    flexGrow: 0,
    backgroundColor: theme.cardBg,
    borderBottomWidth: 1,
    borderBottomColor: theme.borderLight,
  },
  categoryScrollContent: {
    paddingHorizontal: 20,
    paddingVertical: 10,
    gap: 8,
    alignItems: 'center',
  },
  categoryChip: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    paddingHorizontal: 12,
    paddingVertical: 7,
    borderRadius: 20,
    backgroundColor: theme.bg,
    borderWidth: 1,
    borderColor: theme.border,
  },
  categoryChipActiveAll: {
    backgroundColor: theme.primary,
    borderColor: theme.primary,
  },
  categoryDot: {
    width: 8,
    height: 8,
    borderRadius: 4,
  },
  categoryChipText: {
    fontSize: 13,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  categoryChipTextActive: {
    color: '#FFFFFF',
  },
  categoryCount: {
    backgroundColor: theme.borderLight,
    borderRadius: 10,
    minWidth: 20,
    paddingHorizontal: 6,
    paddingVertical: 1,
    alignItems: 'center',
  },
  categoryCountActive: {
    backgroundColor: 'rgba(255,255,255,0.25)',
  },
  categoryCountText: {
    fontSize: 11,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  categoryCountTextActive: {
    color: '#FFFFFF',
  },
  listContent: {
    padding: 16,
    paddingTop: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    marginBottom: 12,
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 16,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-SemiBold',
    fontWeight: '600',
  },
  sectionCount: {
    backgroundColor: theme.borderLight,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  sectionCountText: {
    fontSize: 12,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
});
