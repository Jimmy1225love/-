import { Tabs } from 'expo-router';
import { MapPin, Heart, Settings, Flame } from 'lucide-react-native';
import { useSettings } from '@/hooks/useSettings';

export default function TabLayout() {
  const { theme, language } = useSettings();
  const titles =
    language === 'en'
      ? { deals: 'Deals', map: 'Map', favorites: 'Saved', settings: 'Settings' }
      : { deals: '優惠', map: '地圖', favorites: '收藏', settings: '設定' };

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: theme.primary,
        tabBarInactiveTintColor: theme.textTertiary,
        tabBarLabelStyle: {
          fontFamily: 'NotoSansTC-Medium',
          fontSize: 11,
          fontWeight: '500',
          marginTop: -4,
        },
        tabBarStyle: {
          backgroundColor: theme.cardBg,
          borderTopColor: theme.borderLight,
          borderTopWidth: 1,
          height: 56,
          paddingBottom: 4,
          paddingTop: 4,
        },
        tabBarItemStyle: {
          padding: 0,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: titles.deals,
          tabBarIcon: ({ color, size }) => (
            <Flame color={color} size={size - 2} strokeWidth={2.5} />
          ),
        }}
      />
      <Tabs.Screen
        name="map"
        options={{
          title: titles.map,
          tabBarIcon: ({ color, size }) => (
            <MapPin color={color} size={size - 2} strokeWidth={2.5} />
          ),
        }}
      />
      <Tabs.Screen
        name="favorites"
        options={{
          title: titles.favorites,
          tabBarIcon: ({ color, size }) => (
            <Heart color={color} size={size - 2} strokeWidth={2.5} />
          ),
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: titles.settings,
          tabBarIcon: ({ color, size }) => (
            <Settings color={color} size={size - 2} strokeWidth={2.5} />
          ),
        }}
      />
    </Tabs>
  );
}
