import { useCallback, useMemo } from 'react';
import { StyleSheet, Text, View, SectionList, RefreshControl, Pressable } from 'react-native';
import { useState } from 'react';
import { router } from 'expo-router';
import { Heart, Trash2 } from 'lucide-react-native';
import { theme } from '@/lib/theme';
import { useFavoriteDeals, useFavorites } from '@/hooks/useDeals';
import { useUserLocation } from '@/hooks/useUserLocation';
import { DealCard } from '@/components/DealCard';
import { LoadingState, EmptyState } from '@/components/States';
import type { Deal } from '@/types/deals';
import { urgencyLabel } from '@/lib/helpers';

export default function FavoritesScreen() {
  const { coords } = useUserLocation();
  const { deals, loading, reload } = useFavoriteDeals(coords);
  const { toggleFavorite } = useFavorites();
  const [refreshing, setRefreshing] = useState(false);

  const onRefresh = useCallback(async () => {
    setRefreshing(true);
    await reload();
    setRefreshing(false);
  }, [reload]);

  const handleDealPress = useCallback((deal: Deal) => {
    router.push(`/deal/${deal.id}`);
  }, []);

  const sections = useMemo(() => {
    const active: Deal[] = [];
    const expired: Deal[] = [];

    deals.forEach((deal) => {
      const urgency = urgencyLabel(deal.end_date);
      if (urgency && urgency.label === '已過期') {
        expired.push(deal);
      } else {
        active.push(deal);
      }
    });

    const secs: { title: string; data: Deal[] }[] = [];
    if (active.length > 0) secs.push({ title: '進行中', data: active });
    if (expired.length > 0) secs.push({ title: '已過期', data: expired });
    return secs;
  }, [deals]);

  if (loading) return <LoadingState message="載入收藏..." />;

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.appTitle}>我的收藏</Text>
        <Text style={styles.appSubtitle}>
          {deals.length > 0 ? `已收藏 ${deals.length} 個優惠` : '收藏你感興趣的優惠，方便日後查看'}
        </Text>
      </View>

      {deals.length === 0 ? (
        <View style={styles.emptyWrap}>
          <View style={styles.emptyIconWrap}>
            <Heart size={48} color={theme.textTertiary} strokeWidth={1.5} />
          </View>
          <Text style={styles.emptyTitle}>還沒有收藏</Text>
          <Text style={styles.emptySubtitle}>
            在優惠列表中點擊愛心圖示，就能把好康存起來
          </Text>
          <Pressable style={styles.browseButton} onPress={() => router.push('/')}>
            <Text style={styles.browseButtonText}>瀏覽優惠</Text>
          </Pressable>
        </View>
      ) : (
        <SectionList
          sections={sections}
          keyExtractor={(item) => item.id}
          renderSectionHeader={({ section }) => (
            <View style={styles.sectionHeader}>
              <Text style={styles.sectionTitle}>{section.title}</Text>
              <View style={styles.sectionCount}>
                <Text style={styles.sectionCountText}>{section.data.length}</Text>
              </View>
            </View>
          )}
          renderItem={({ item }) => (
            <View>
              <DealCard
                deal={item}
                isFavorite={true}
                onToggleFavorite={toggleFavorite}
                onPress={handleDealPress}
              />
              {sections[1] && sections[1].data.includes(item) && (
                <Pressable
                  style={styles.removeRow}
                  onPress={() => toggleFavorite(item.id)}
                >
                  <Trash2 size={14} color={theme.textTertiary} strokeWidth={2} />
                  <Text style={styles.removeText}>移除收藏</Text>
                </Pressable>
              )}
            </View>
          )}
          contentContainerStyle={styles.listContent}
          refreshControl={
            <RefreshControl refreshing={refreshing} onRefresh={onRefresh} tintColor={theme.primary} />
          }
          showsVerticalScrollIndicator={false}
          stickySectionHeadersEnabled={false}
        />
      )}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.bg,
  },
  header: {
    paddingHorizontal: 20,
    paddingTop: 56,
    paddingBottom: 16,
    backgroundColor: theme.cardBg,
    borderBottomWidth: 1,
    borderBottomColor: theme.borderLight,
  },
  appTitle: {
    fontSize: 28,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
    letterSpacing: -0.5,
  },
  appSubtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
    marginTop: 4,
  },
  emptyWrap: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    paddingHorizontal: 32,
  },
  emptyIconWrap: {
    width: 96,
    height: 96,
    borderRadius: 48,
    backgroundColor: theme.cardBg,
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
    borderWidth: 1,
    borderColor: theme.borderLight,
  },
  emptyTitle: {
    fontSize: 20,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-SemiBold',
    fontWeight: '600',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
    textAlign: 'center',
    lineHeight: 22,
    marginBottom: 24,
  },
  browseButton: {
    backgroundColor: theme.primary,
    paddingHorizontal: 28,
    paddingVertical: 12,
    borderRadius: 12,
  },
  browseButtonText: {
    fontSize: 15,
    color: '#FFFFFF',
    fontFamily: 'NotoSansTC-SemiBold',
    fontWeight: '600',
  },
  listContent: {
    padding: 16,
    paddingTop: 16,
  },
  sectionHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 12,
    marginTop: 8,
  },
  sectionTitle: {
    fontSize: 16,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-SemiBold',
    fontWeight: '600',
  },
  sectionCount: {
    backgroundColor: theme.borderLight,
    borderRadius: 8,
    paddingHorizontal: 8,
    paddingVertical: 2,
  },
  sectionCountText: {
    fontSize: 12,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  removeRow: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 6,
    paddingVertical: 8,
    marginBottom: 12,
  },
  removeText: {
    fontSize: 13,
    color: theme.textTertiary,
    fontFamily: 'NotoSansTC-Regular',
  },
});
