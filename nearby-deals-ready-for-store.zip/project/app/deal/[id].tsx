import { useEffect, useState, useMemo } from 'react';
import {
  StyleSheet,
  Text,
  View,
  ScrollView,
  Pressable,
  Linking,
  Platform,
} from 'react-native';
import { useLocalSearchParams, router } from 'expo-router';
import {
  ChevronLeft,
  Heart,
  MapPin,
  Clock,
  Tag,
  Navigation,
  Share2,
} from 'lucide-react-native';
import { supabase } from '@/lib/supabase';
import { theme } from '@/lib/theme';
import {
  formatPrice,
  formatDistance,
  urgencyLabel,
  daysUntil,
  calculateDistanceMeters,
} from '@/lib/helpers';
import { useFavorites } from '@/hooks/useDeals';
import { useUserLocation } from '@/hooks/useUserLocation';
import { LoadingState, ErrorState } from '@/components/States';
import type { Deal } from '@/types/deals';

export default function DealDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const [deal, setDeal] = useState<Deal | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const { isFavorite, toggleFavorite } = useFavorites();
  const { coords } = useUserLocation();

  useEffect(() => {
    async function loadDeal() {
      if (!id) return;
      const { data, error: queryError } = await supabase
        .from('deals')
        .select('*, categories(*)')
        .eq('id', id)
        .maybeSingle();

      if (queryError) {
        setError('無法載入優惠資料');
        setLoading(false);
        return;
      }

      if (!data) {
        setError('找不到此優惠');
        setLoading(false);
        return;
      }

      setDeal(data as Deal);
      setLoading(false);
    }
    loadDeal();
  }, [id]);

  // Override distance with live calculation when we have user location
  const displayDeal = useMemo(() => {
    if (!deal) return null;
    if (!coords || deal.latitude == null || deal.longitude == null) return deal;
    const meters = calculateDistanceMeters(
      coords.latitude,
      coords.longitude,
      deal.latitude,
      deal.longitude
    );
    return { ...deal, distance_meters: Math.round(meters) };
  }, [deal, coords]);

  const handleNavigate = () => {
    if (deal?.latitude && deal?.longitude) {
      const url = Platform.select({
        ios: `maps://app?daddr=${deal.latitude},${deal.longitude}`,
        android: `google.navigation:q=${deal.latitude},${deal.longitude}`,
        web: `https://www.google.com/maps/dir/?api=1&destination=${deal.latitude},${deal.longitude}`,
      });
      if (url) Linking.openURL(url);
    }
  };

  const handleShare = async () => {
    if (!deal) return;
    try {
      await Share2;
      if (Platform.OS === 'web') {
        if (navigator.share) {
          navigator.share({ title: deal.title, text: deal.description || deal.title });
        }
      }
    } catch {
      // silently ignore share errors
    }
  };

  if (loading) return <LoadingState message="載入優惠詳情..." />;
  if (error || !deal || !displayDeal)
    return <ErrorState message={error || '發生錯誤'} onRetry={() => router.back()} retryLabel="返回" />;

  const urgency = urgencyLabel(displayDeal.end_date);
  const fav = isFavorite(displayDeal.id);
  const hasDiscount =
    displayDeal.original_price !== null &&
    displayDeal.discount_price !== null &&
    displayDeal.original_price > displayDeal.discount_price;

  return (
    <View style={styles.container}>
      <View style={styles.topBar}>
        <Pressable
          style={styles.backButton}
          hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          onPress={() => router.back()}
        >
          <ChevronLeft size={24} color={theme.textPrimary} strokeWidth={2.5} />
        </Pressable>
        <Pressable
          style={styles.shareButton}
          hitSlop={{ top: 12, bottom: 12, left: 12, right: 12 }}
          onPress={handleShare}
        >
          <Share2 size={20} color={theme.textPrimary} strokeWidth={2.5} />
        </Pressable>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={styles.scrollContent}>
        <View style={styles.heroSection}>
          <View style={styles.storePill}>
            <Tag size={14} color={theme.primary} strokeWidth={2.5} />
            <Text style={styles.storePillText}>{deal.store_name}</Text>
          </View>
          {deal.categories && (
            <View style={[styles.categoryTag, { backgroundColor: `${deal.categories.color}15` }]}>
              <Text style={[styles.categoryTagText, { color: deal.categories.color }]}>
                {deal.categories.name}
              </Text>
            </View>
          )}
        </View>

        <Text style={styles.dealTitle}>{deal.title}</Text>

        {deal.description && (
          <Text style={styles.description}>{deal.description}</Text>
        )}

        {hasDiscount && (
          <View style={styles.priceCard}>
            <View style={styles.priceLeft}>
              <Text style={styles.priceLabel}>折扣價</Text>
              <View style={styles.priceRow}>
                <Text style={styles.originalPriceLarge}>
                  {formatPrice(deal.original_price)}
                </Text>
                <Text style={styles.discountPriceLarge}>
                  {formatPrice(deal.discount_price)}
                </Text>
              </View>
              <Text style={styles.savingsText}>
                省 {formatPrice((deal.original_price ?? 0) - (deal.discount_price ?? 0))}
              </Text>
            </View>
            {deal.discount_percentage !== null && deal.discount_percentage > 0 && (
              <View style={styles.percentageCircle}>
                <Text style={styles.percentageNumber}>{deal.discount_percentage}</Text>
                <Text style={styles.percentageSign}>%OFF</Text>
              </View>
            )}
          </View>
        )}

        {deal.tags && deal.tags.length > 0 && (
          <View style={styles.tagsSection}>
            <Text style={styles.sectionLabel}>標籤</Text>
            <View style={styles.tagsWrap}>
              {deal.tags.map((tag, i) => (
                <View key={i} style={styles.tagPill}>
                  <Text style={styles.tagPillText}>{tag}</Text>
                </View>
              ))}
            </View>
          </View>
        )}

        <View style={styles.infoSection}>
          <View style={styles.infoRow}>
            <Clock size={18} color={theme.textSecondary} strokeWidth={2.5} />
            <View style={styles.infoContent}>
              <Text style={styles.infoLabel}>優惠期間</Text>
              <Text style={styles.infoValue}>
                {deal.start_date || '?'} ~ {deal.end_date || '?'}
              </Text>
            </View>
            {urgency && (
              <View style={[styles.urgencyBadge, { backgroundColor: `${urgency.color}15` }]}>
                <Text style={[styles.urgencyBadgeText, { color: urgency.color }]}>
                  {urgency.label}
                </Text>
              </View>
            )}
          </View>

          {displayDeal.distance_meters !== null && (
            <View style={styles.infoRow}>
              <MapPin size={18} color={theme.textSecondary} strokeWidth={2.5} />
              <View style={styles.infoContent}>
                <Text style={styles.infoLabel}>距離</Text>
                <Text style={styles.infoValue}>
                  {formatDistance(displayDeal.distance_meters)} 外
                </Text>
              </View>
            </View>
          )}
        </View>

        {deal.latitude && deal.longitude && (
          <Pressable style={styles.navigateButton} onPress={handleNavigate}>
            <Navigation size={18} color="#FFFFFF" strokeWidth={2.5} />
            <Text style={styles.navigateButtonText}>導航前往</Text>
          </Pressable>
        )}
      </ScrollView>

      <View style={styles.bottomBar}>
        <Pressable
          style={[styles.favButton, fav && styles.favButtonActive]}
          onPress={() => toggleFavorite(deal.id)}
        >
          <Heart
            size={22}
            color={fav ? '#FFFFFF' : theme.error}
            fill={fav ? '#FFFFFF' : 'transparent'}
            strokeWidth={2}
          />
          <Text style={[styles.favButtonText, fav && styles.favButtonTextActive]}>
            {fav ? '已收藏' : '收藏'}
          </Text>
        </Pressable>
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.bg,
  },
  topBar: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    paddingHorizontal: 16,
    paddingTop: 56,
    paddingBottom: 8,
    backgroundColor: theme.cardBg,
  },
  backButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: theme.bg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  shareButton: {
    width: 40,
    height: 40,
    borderRadius: 20,
    backgroundColor: theme.bg,
    alignItems: 'center',
    justifyContent: 'center',
  },
  scrollContent: {
    padding: 20,
    paddingBottom: 100,
  },
  heroSection: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 8,
    marginBottom: 16,
    flexWrap: 'wrap',
  },
  storePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    backgroundColor: theme.primaryLight,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
  },
  storePillText: {
    fontSize: 13,
    color: theme.primary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  categoryTag: {
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
  },
  categoryTagText: {
    fontSize: 13,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  dealTitle: {
    fontSize: 24,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
    lineHeight: 34,
    marginBottom: 12,
  },
  description: {
    fontSize: 15,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
    lineHeight: 24,
    marginBottom: 20,
  },
  priceCard: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    backgroundColor: theme.cardBg,
    borderRadius: 16,
    padding: 20,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: theme.borderLight,
    shadowColor: theme.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 3,
  },
  priceLeft: {
    flex: 1,
  },
  priceLabel: {
    fontSize: 12,
    color: theme.textTertiary,
    fontFamily: 'NotoSansTC-Regular',
    marginBottom: 4,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'baseline',
    gap: 8,
    marginBottom: 4,
  },
  originalPriceLarge: {
    fontSize: 16,
    color: theme.textTertiary,
    fontFamily: 'NotoSansTC-Regular',
    textDecorationLine: 'line-through',
  },
  discountPriceLarge: {
    fontSize: 32,
    color: theme.error,
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
  },
  savingsText: {
    fontSize: 13,
    color: theme.success,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  percentageCircle: {
    width: 72,
    height: 72,
    borderRadius: 36,
    backgroundColor: theme.error,
    alignItems: 'center',
    justifyContent: 'center',
  },
  percentageNumber: {
    fontSize: 24,
    color: '#FFFFFF',
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
    lineHeight: 28,
  },
  percentageSign: {
    fontSize: 10,
    color: '#FFFFFF',
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
  },
  tagsSection: {
    marginBottom: 20,
  },
  sectionLabel: {
    fontSize: 14,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
    marginBottom: 10,
  },
  tagsWrap: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: 8,
  },
  tagPill: {
    backgroundColor: theme.cardBg,
    paddingHorizontal: 12,
    paddingVertical: 6,
    borderRadius: 10,
    borderWidth: 1,
    borderColor: theme.border,
  },
  tagPillText: {
    fontSize: 13,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
  },
  infoSection: {
    backgroundColor: theme.cardBg,
    borderRadius: 16,
    padding: 16,
    marginBottom: 20,
    borderWidth: 1,
    borderColor: theme.borderLight,
    gap: 16,
  },
  infoRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 12,
  },
  infoContent: {
    flex: 1,
  },
  infoLabel: {
    fontSize: 12,
    color: theme.textTertiary,
    fontFamily: 'NotoSansTC-Regular',
    marginBottom: 2,
  },
  infoValue: {
    fontSize: 15,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  urgencyBadge: {
    paddingHorizontal: 10,
    paddingVertical: 4,
    borderRadius: 8,
  },
  urgencyBadgeText: {
    fontSize: 12,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  navigateButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: theme.primary,
    borderRadius: 14,
    paddingVertical: 14,
  },
  navigateButtonText: {
    fontSize: 15,
    color: '#FFFFFF',
    fontFamily: 'NotoSansTC-SemiBold',
    fontWeight: '600',
  },
  bottomBar: {
    position: 'absolute',
    bottom: 0,
    left: 0,
    right: 0,
    backgroundColor: theme.cardBg,
    borderTopColor: theme.borderLight,
    borderTopWidth: 1,
    paddingHorizontal: 20,
    paddingVertical: 12,
    paddingBottom: 24,
  },
  favButton: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: 8,
    backgroundColor: theme.errorLight,
    borderRadius: 14,
    paddingVertical: 14,
  },
  favButtonActive: {
    backgroundColor: theme.error,
  },
  favButtonText: {
    fontSize: 15,
    color: theme.error,
    fontFamily: 'NotoSansTC-SemiBold',
    fontWeight: '600',
  },
  favButtonTextActive: {
    color: '#FFFFFF',
  },
});
