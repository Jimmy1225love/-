import { useEffect } from 'react';
import { Stack } from 'expo-router';
import { StatusBar } from 'expo-status-bar';
import { useFonts } from 'expo-font';
import * as SplashScreen from 'expo-splash-screen';
import {
  NotoSansTC_400Regular,
  NotoSansTC_500Medium,
  NotoSansTC_700Bold,
} from '@expo-google-fonts/noto-sans-tc';
import { useFrameworkReady } from '@/hooks/useFrameworkReady';
import { FavoritesProvider } from '@/hooks/useFavorites';
import { SettingsProvider, useSettings } from '@/hooks/useSettings';
import { LocationProvider } from '@/hooks/useUserLocation';

SplashScreen.preventAutoHideAsync();

function RootStatusBar() {
  const { darkMode } = useSettings();
  return <StatusBar style={darkMode ? 'light' : 'dark'} />;
}

export default function RootLayout() {
  useFrameworkReady();

  const [fontsLoaded, fontError] = useFonts({
    'NotoSansTC-Regular': NotoSansTC_400Regular,
    'NotoSansTC-Medium': NotoSansTC_500Medium,
    'NotoSansTC-SemiBold': NotoSansTC_700Bold,
    'NotoSansTC-Bold': NotoSansTC_700Bold,
  });

  useEffect(() => {
    if (fontsLoaded || fontError) {
      SplashScreen.hideAsync();
    }
  }, [fontsLoaded, fontError]);

  if (!fontsLoaded && !fontError) {
    return null;
  }

  return (
    <SettingsProvider>
      <LocationProvider>
        <FavoritesProvider>
          <Stack screenOptions={{ headerShown: false }}>
            <Stack.Screen name="(tabs)" />
            <Stack.Screen name="deal/[id]" />
            <Stack.Screen name="+not-found" />
          </Stack>
          <RootStatusBar />
        </FavoritesProvider>
      </LocationProvider>
    </SettingsProvider>
  );
}
