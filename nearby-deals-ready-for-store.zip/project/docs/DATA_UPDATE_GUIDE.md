# 優惠資料更新指南（維持 App 不「空殼」）

上架後最重要的是：**定期有新的、未過期的優惠**。

---

## 建議節奏

| 頻率 | 動作 |
|------|------|
| 每週 1 次 | 更新超市 DM／App 限時優惠 |
| 有大型檔期前 | 中秋、聖誕、七一、國慶等提前補資料 |
| 每天（可選） | 用 SQL 下架已過期：`end_date < today` |

App 端已會過濾 `end_date < 今天`，但仍建議資料庫不要堆太多過期列。

---

## 方法一：手動（現階段最穩）

1. 打開惠康 / 百佳 / OpenRice / U Food 等公開優惠頁  
2. 把標題、店名、價錢、日期、大致座標整理好  
3. 在 Supabase SQL Editor 執行 `INSERT`（可參考 `supabase/seed/hk_deals_seed.sql`）  
4. 或把網頁連結給 AI（例如 Grok）幫忙產出 SQL 再貼上  

**範本：**

```sql
INSERT INTO deals (
  title, description, store_name, category_id,
  original_price, discount_price, discount_percentage,
  latitude, longitude, start_date, end_date, is_featured, tags
) VALUES (
  '標題',
  '說明',
  '店名',
  (SELECT id FROM categories WHERE name = '超市' LIMIT 1),
  100, 80, 20,
  22.28, 114.15,
  '2026-09-15', '2026-09-21',
  true,
  ARRAY['限時', '會員']
);
```

---

## 方法二：半自動（建議 1 個月內做到）

1. 用 **n8n** 或 **Make.com** 每週一跑一次  
2. 步驟：抓公開頁 → 呼叫 LLM 轉成 JSON → Supabase Upsert  
3. 失敗時發電郵通知你人工檢查  

重點：只抓**公開網頁**，遵守 robots 與網站條款，不要登入牆後內容。

---

## 方法三：使用者投稿（之後）

- App 內「回報優惠」表單 → 進審核表 → 你批准後才顯示  
- 可增加在地小店，但需要審核人力  

---

## 清理過期資料

```sql
-- 僅預覽
SELECT id, title, end_date FROM deals WHERE end_date < CURRENT_DATE;

-- 刪除（可改成 is_active = false 若你有該欄）
DELETE FROM deals WHERE end_date < CURRENT_DATE - INTERVAL '7 days';
```

---

## 分店座標

新品牌或新區：在 `stores` 表加列，再視需要把 `deals.store_id` 連上。  
參考：`supabase/seed/hk_stores_seed.sql`。

---

## 檢查清單（每次更新後）

- [ ] 新優惠 `end_date` 在未來  
- [ ] `category_id` 正確  
- [ ] 至少有 lat/lng（可用品牌代表分店座標）  
- [ ] 在 App 下拉重新整理看得到  
- [ ] 地圖上位置合理（香港範圍內）
