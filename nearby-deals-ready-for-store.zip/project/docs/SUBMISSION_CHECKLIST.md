# 上架檢查清單（iOS App Store + Google Play）

逐項打勾後再送審。

---

## A. 開發者帳號

- [ ] Apple Developer Program（年費，約 USD 99）
- [ ] Google Play Console（一次註冊費，約 USD 25）
- [ ] 帳號實名 / 公司資料完成驗證

---

## B. 專案設定

- [ ] `app.json` 中 name、slug、version 已改為正式名稱
- [ ] iOS `bundleIdentifier` 已設定（例如 `com.xxx.nearbydeals`）
- [ ] Android `package` 已設定
- [ ] 版本號：`version`（使用者看到）+ `ios.buildNumber` / `android.versionCode`
- [ ] 定位權限文案已寫入（繁中，清楚說明用途）
- [ ] 地圖 API Key（若用 Google Maps）已填且限制包名／Bundle ID
- [ ] 正式 Supabase URL / anon key 使用 production 專案（不要用測試亂資料）

---

## C. 法律與商店頁

- [ ] 隱私權政策已上線為**可公開網址**（HTTPS）
- [ ] 服務條款可公開存取（可與隱私權同一網站）
- [ ] App 內設定頁可連到隱私權政策（建議）
- [ ] 商店描述、關鍵字、分類、年齡分級已填
- [ ] 隱私問卷（Apple App Privacy / Google Data safety）已如實填寫：
  - 收集「位置」→ App 功能
  - 收集「裝置或識別碼」→ 用於收藏（匿名）
  - 不出售資料

---

## D. 素材

- [ ] App Icon 1024×1024（無透明、無圓角；Android 另備 adaptive icon）
- [ ] Splash / 啟動畫面
- [ ] 商店截圖至少 3 張（建議 5 張），含列表、地圖、詳情
- [ ]（選）宣傳圖 Feature Graphic（Google Play 1024×500）

---

## E. 功能與資料

- [ ] 真實優惠 seed 已寫入 production 資料庫
- [ ] 過期優惠不會大面積顯示（end_date 過濾正常）
- [ ] 拒絕定位時 App 仍可開啟（顯示全部或提示開權限）
- [ ] 無網路時有錯誤提示，不會白屏
- [ ] 收藏開關正常
- [ ] 分類篩選、搜尋、距離正常

---

## F. 建置與簽名

### iOS
- [ ] 用 EAS 或 Xcode 建 Archive
- [ ] 用 Distribution 憑證 + App Store provisioning profile
- [ ] 上傳至 App Store Connect
- [ ] 填「審核備註」（如何測試、是否需登入→否）

### Android
- [ ] 建立 upload keystore 並安全備份
- [ ] EAS / Gradle 打出 AAB（非只 APK）
- [ ] 上傳至 Play Console 正式軌或內部測試軌先測

---

## G. 送審前最後檢查

- [ ] 用 TestFlight / 內部測試至少 1 人實機跑過
- [ ] 隱私權網址在瀏覽器可打開
- [ ] 沒有 placeholder 文案（「請填入」「lorem」等）
- [ ] 沒有當機、明顯錯字

---

## H. 建議但不擋上架

- [ ] Sentry 或同等崩潰回報
- [ ] 簡單分析（開啟次數）
- [ ] 每週更新優惠的流程已定（見 DATA_UPDATE_GUIDE.md）
- [ ] 支援電郵或 Instagram 客服入口

---

## 常用指令（Expo EAS）

```bash
# 安裝 EAS CLI
npm i -g eas-cli
eas login

# 設定專案
eas build:configure

# 建 iOS / Android 正式包
eas build --platform ios --profile production
eas build --platform android --profile production

# 提交 iOS（需先在 App Store Connect 建好 App）
eas submit --platform ios
```

---

完成 A–G 後即可送審。首次 iOS 審核約 24–48 小時（有時更長）；Android 通常更快。
