# App Store / Google Play 商店文案

---

## 基本資料

| 欄位 | 建議內容 |
|------|----------|
| **App 名稱（繁中）** | 附近優惠 |
| **App 名稱（英文）** | Nearby Deals HK |
| **副標題 / 簡短說明** | 香港超市餐廳優惠，依距離找著數 |
| **Bundle ID (iOS)** | com.yourname.nearbydeals |
| **Application ID (Android)** | com.yourname.nearbydeals |
| **分類** | 生活風格 / Lifestyle 或 購物 / Shopping |
| **年齡分級** | 4+ / 所有人（無不良內容） |
| **價格** | 免費 |

> 請把 `com.yourname.nearbydeals` 改成你自己的網域反向命名。

---

## 完整描述（繁體中文）

**附近優惠 — 香港超市與餐廳著數一手掌握**

想知附近邊間超市減價、邊間餐廳有優惠？「附近優惠」幫你用位置找出周圍的好康。

**主要功能**
• 依你的位置顯示附近優惠與距離  
• 超市、飲食等分類快速篩選  
• 地圖一覽門市位置  
• 收藏喜歡的優惠，下次一打開就睇到  
• 搜尋店名、標籤或優惠關鍵字  
• 依距離、折扣、到期日排序  

**涵蓋類型**
超市（惠康、百佳等）、快餐與餐廳、平台與期間限定優惠。

**注意**
優惠內容僅供參考，實際以商戶門市為準。使用定位功能需你授權，可隨時在系統設定關閉。

立即下載，行出街都唔會錯過著數！

---

## Short description（Google Play，最多 80 字元）

香港超市餐廳優惠，依距離找附近著數。地圖、收藏、分類篩選。

---

## 完整描述（English）

**Nearby Deals HK — Find supermarket & restaurant offers around you**

See what’s on promo near you in Hong Kong. Filter by category, sort by distance or discount, save favourites, and explore on the map.

Offers are for reference only; please confirm at the store. Location is used only to calculate distance and is not used to track you.

---

## 關鍵字建議（ASO）

香港優惠, 超市減價, 附近優惠, 惠康, 百佳, 餐廳優惠, 著數, 地圖優惠, Wellcome, PARKnSHOP, deals near me

---

## 權限說明（商店問卷用）

| 權限 | 用途說明 |
|------|----------|
| 位置（使用期間） | 計算與門市距離、顯示附近優惠與地圖 |
| 網路 | 載入優惠資料 |

不需要：通訊錄、相機、麥克風、通訊紀錄。

---

## 截圖建議（最少 3–5 張）

1. 首頁列表 + 分類 chips  
2. 搜尋 / 篩選結果  
3. 地圖頁  
4. 優惠詳情  
5. 收藏頁  

建議用 iPhone 6.7" 與 Android 手機實機或模擬器截圖，避免過多空白。

---

## 審核備註（給 Apple / Google）

本 App 無需登入。主要功能為瀏覽香港公開優惠資訊。  
定位僅用於距離計算，使用者可拒絕授權。  
測試時請允許定位，或於設定中關閉「僅顯示附近」以查看全部資料。
