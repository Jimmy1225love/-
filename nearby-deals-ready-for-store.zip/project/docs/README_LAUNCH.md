# 附近優惠 — 上架準備總覽

本資料夾包含送審與營運所需文件。請依序處理。

---

## 文件一覽

| 檔案 | 用途 |
|------|------|
| `PRIVACY_POLICY.md` | 隱私權政策全文 → 請放到你的網站變成 HTTPS 網址 |
| `TERMS_OF_SERVICE.md` | 服務條款 → 同上 |
| `STORE_LISTING.md` | App Store / Google Play 名稱、描述、關鍵字、截圖建議 |
| `SUBMISSION_CHECKLIST.md` | 送審前逐項檢查清單 + EAS 指令 |
| `DATA_UPDATE_GUIDE.md` | 上架後如何持續更新優惠，避免空殼 |
| `README_LAUNCH.md` | 本說明 |

---

## 你必須自己完成的 5 件事

1. **替換佔位字串**
   - `com.yourname.nearbydeals` → 你的 Bundle ID / package
   - `https://yourdomain.com/privacy` 與 `/terms` → 真實網址
   - 隱私權／條款裡的聯絡電郵

2. **把隱私權與條款放到公開網頁**  
   可用 GitHub Pages、Cloudflare Pages、自家網域。審核會點開檢查。

3. **註冊開發者帳號**  
   Apple Developer + Google Play Console。

4. **準備 Icon 與截圖**  
   1024 icon + 至少 3 張商店截圖（見 STORE_LISTING.md）。

5. **Production 資料庫**  
   在正式 Supabase 跑 migrations + seed，確認 App 連的是正式 key。

---

## 建議時程

| 天 | 工作 |
|----|------|
| Day 1 | 上線隱私權／條款網頁；改 app.json 的 ID 與網址 |
| Day 2 | Icon、截圖；TestFlight / 內部測試 |
| Day 3 | 填商店資料、隱私問卷；EAS Build |
| Day 4 | 送審 |

---

## 無法代勞的部分

- 付款註冊 Apple / Google 帳號  
- 上傳簽名後的正式包（需你的憑證）  
- 商店後台點「提交審核」  

其餘文案、權限、檢查清單、資料更新流程已在本專案備好。
