/*
  # Create stores table and link to deals

  1. New Table: stores
  - id (uuid, primary key)
  - name (text) — full store name e.g. "惠康 (中環)"
  - brand (text) — brand group e.g. "惠康 Wellcome", "百佳 PARKnSHOP"
  - address (text)
  - district (text) — e.g. 中西區, 油尖旺, 灣仔
  - latitude / longitude
  - category_hint (text) — 超市 / 飲食 / 便利店 (optional helper)
  - is_active (boolean)
  - created_at

  2. Alter deals
  - Add store_id (uuid, nullable, references stores)
  - Keep store_name for backward compatibility / display

  3. Indexes & RLS
  - Public SELECT only (same pattern as deals)
*/

-- 1. stores table
CREATE TABLE IF NOT EXISTS stores (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  brand text NOT NULL,
  address text,
  district text,
  latitude double precision NOT NULL,
  longitude double precision NOT NULL,
  category_hint text,
  is_active boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Unique-ish constraint: same brand + nearly same location should not duplicate
CREATE UNIQUE INDEX IF NOT EXISTS idx_stores_brand_lat_lng
  ON stores (brand, latitude, longitude);

CREATE INDEX IF NOT EXISTS idx_stores_brand ON stores(brand);
CREATE INDEX IF NOT EXISTS idx_stores_district ON stores(district);
CREATE INDEX IF NOT EXISTS idx_stores_active ON stores(is_active);

-- 2. Link deals → stores (nullable so old rows still work)
ALTER TABLE deals
  ADD COLUMN IF NOT EXISTS store_id uuid REFERENCES stores(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS idx_deals_store ON deals(store_id);

-- 3. RLS
ALTER TABLE stores ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "public_select_stores" ON stores;
CREATE POLICY "public_select_stores"
  ON stores
  FOR SELECT
  TO anon, authenticated
  USING (true);
