/*
# Create deals and categories tables (single-tenant, no auth)

1. New Tables
- `categories` — store types (supermarket, restaurant, etc.)
  - id (uuid, primary key)
  - name (text, unique, not null)
  - icon_name (text) — lucide icon name for the category
  - color (text) — hex color for category badge
  - created_at (timestamp)

- `deals` — individual promotions/deals at nearby stores
  - id (uuid, primary key)
  - title (text, not null) — deal headline
  - description (text) — details of the offer
  - store_name (text, not null) — e.g. "全聯福利中心", "星巴克"
  - category_id (uuid, references categories)
  - original_price (numeric) — original price before discount
  - discount_price (numeric) — discounted/sale price
  - discount_percentage (integer) — calculated or manual percentage off
  - image_url (text) — store or product image URL
  - latitude (double precision) — store location lat
  - longitude (double precision) — store location lng
  - distance_meters (integer) — precomputed distance for sorting
  - start_date (date) — when the deal begins
  - end_date (date) — when the deal expires
  - is_featured (boolean, default false) — highlight on home screen
  - tags (text[]) — searchable tags like "限時", "買一送一", "即期品"
  - created_at (timestamp)

- `favorite_deals` — user favorites (single-tenant, stored locally by device)
  - id (uuid, primary key)
  - deal_id (uuid, references deals, on delete cascade)
  - device_id (text) — pseudo-unique identifier for the anonymous user
  - created_at (timestamp)

2. Security
- Enable RLS on all tables.
- categories & deals: public SELECT only. Writes use service role (dashboard / seed).
- favorite_deals: SELECT / INSERT / DELETE for anon (app filters by device_id).
  INSERT requires a non-empty device_id (length >= 16). No UPDATE policy.
  Without auth.uid() true row isolation is not possible; device_ids are random
  and hard to guess. For stronger isolation, migrate to Anonymous Auth.
3. Indexes
- Index deals by category_id, is_featured, end_date.
- Index favorite_deals by device_id + deal_id.
*/

CREATE TABLE IF NOT EXISTS categories (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  icon_name text NOT NULL DEFAULT 'Tag',
  color text NOT NULL DEFAULT '#2563EB',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  title text NOT NULL,
  description text,
  store_name text NOT NULL,
  category_id uuid REFERENCES categories(id) ON DELETE SET NULL,
  original_price numeric(10,2),
  discount_price numeric(10,2),
  discount_percentage integer,
  image_url text,
  latitude double precision,
  longitude double precision,
  distance_meters integer,
  start_date date,
  end_date date,
  is_featured boolean NOT NULL DEFAULT false,
  tags text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS favorite_deals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  deal_id uuid NOT NULL REFERENCES deals(id) ON DELETE CASCADE,
  device_id text NOT NULL,
  created_at timestamptz DEFAULT now(),
  UNIQUE(deal_id, device_id)
);

CREATE INDEX IF NOT EXISTS idx_deals_category ON deals(category_id);
CREATE INDEX IF NOT EXISTS idx_deals_featured ON deals(is_featured);
CREATE INDEX IF NOT EXISTS idx_deals_end_date ON deals(end_date);
CREATE INDEX IF NOT EXISTS idx_favorites_device ON favorite_deals(device_id);
CREATE INDEX IF NOT EXISTS idx_favorites_deal_device ON favorite_deals(deal_id, device_id);

ALTER TABLE categories ENABLE ROW LEVEL SECURITY;
ALTER TABLE deals ENABLE ROW LEVEL SECURITY;
ALTER TABLE favorite_deals ENABLE ROW LEVEL SECURITY;

-- Categories: public SELECT only (writes via service role / dashboard)
DROP POLICY IF EXISTS "anon_select_categories" ON categories;
DROP POLICY IF EXISTS "anon_insert_categories" ON categories;
DROP POLICY IF EXISTS "anon_update_categories" ON categories;
DROP POLICY IF EXISTS "anon_delete_categories" ON categories;
DROP POLICY IF EXISTS "public_select_categories" ON categories;

CREATE POLICY "public_select_categories"
  ON categories
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Deals: public SELECT only (writes via service role / dashboard)
DROP POLICY IF EXISTS "anon_select_deals" ON deals;
DROP POLICY IF EXISTS "anon_insert_deals" ON deals;
DROP POLICY IF EXISTS "anon_update_deals" ON deals;
DROP POLICY IF EXISTS "anon_delete_deals" ON deals;
DROP POLICY IF EXISTS "public_select_deals" ON deals;

CREATE POLICY "public_select_deals"
  ON deals
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Favorites: app filters by device_id; INSERT requires a valid device_id
DROP POLICY IF EXISTS "anon_select_favorites" ON favorite_deals;
DROP POLICY IF EXISTS "anon_insert_favorites" ON favorite_deals;
DROP POLICY IF EXISTS "anon_delete_favorites" ON favorite_deals;
DROP POLICY IF EXISTS "anon_update_favorites" ON favorite_deals;
DROP POLICY IF EXISTS "public_select_favorites" ON favorite_deals;
DROP POLICY IF EXISTS "public_insert_favorites" ON favorite_deals;
DROP POLICY IF EXISTS "public_delete_favorites" ON favorite_deals;

CREATE POLICY "public_select_favorites"
  ON favorite_deals
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "public_insert_favorites"
  ON favorite_deals
  FOR INSERT
  TO anon, authenticated
  WITH CHECK (
    device_id IS NOT NULL
    AND length(trim(device_id)) >= 16
  );

CREATE POLICY "public_delete_favorites"
  ON favorite_deals
  FOR DELETE
  TO anon, authenticated
  USING (true);

-- No UPDATE policy → updates denied under RLS

