-- ============================================================
-- Hong Kong Nearby Deals Seed Data
-- Generated: 2026-09-12
-- Covers: Supermarkets (Wellcome, PARKnSHOP) + Restaurants
-- Valid roughly: mid-September 2026 onwards
-- 
-- How to use:
-- 1. Run the migration first (create tables)
-- 2. Paste this entire file into Supabase SQL Editor and run
-- ============================================================

-- 1. Categories
INSERT INTO categories (name, icon_name, color) VALUES
  ('超市', 'ShoppingCart', '#2563EB'),
  ('便利店', 'Store', '#059669'),
  ('飲食', 'Utensils', '#EA580C'),
  ('日用品', 'Home', '#7C3AED'),
  ('即期品', 'Clock', '#DC2626')
ON CONFLICT (name) DO NOTHING;

-- 2. Supermarket Deals (Wellcome / PARKnSHOP)
INSERT INTO deals (
  title,
  description,
  store_name,
  category_id,
  original_price,
  discount_price,
  discount_percentage,
  latitude,
  longitude,
  start_date,
  end_date,
  is_featured,
  tags
) VALUES
-- Wellcome
(
  '雪糕雪條5件或以上8折',
  '任選雀巢Drumstick甜筒、宮田雪糕筒、Dreyer’s、日本樂天沙冰、森永Pino等單件裝雪糕/雪條，買5件或以上即享8折。門市限定。',
  '惠康 Wellcome',
  (SELECT id FROM categories WHERE name = '超市' LIMIT 1),
  NULL, NULL, 20,
  22.2832, 114.1551,
  '2026-09-11', '2026-09-17',
  true,
  ARRAY['限時', '雪糕', '8折', '門市限定']
),
(
  '買2排指定汽水送出前一丁+紙巾+飲品',
  '買2排可口可樂/雪碧/玉泉/芬達8罐裝或梳打水，即送出前一丁麵、Meadows紙巾及陽光飲品（總值約$52）。門市限定。',
  '惠康 Wellcome',
  (SELECT id FROM categories WHERE name = '超市' LIMIT 1),
  NULL, NULL, NULL,
  22.3177, 114.1702,
  '2026-09-11', '2026-09-17',
  true,
  ARRAY['買贈', '汽水', '限時']
),
(
  '買4支舒適達牙膏送總值$296禮品',
  '買4支舒適達單支裝牙膏（100克），送維達紙巾、唯潔雅面紙、威潔33洗衣珠、滴露沐浴露、斧頭牌洗潔精及威露士洗手液（總值$296）。',
  '惠康 Wellcome',
  (SELECT id FROM categories WHERE name = '日用品' LIMIT 1),
  NULL, NULL, NULL,
  22.2781, 114.1777,
  '2026-09-11', '2026-09-17',
  true,
  ARRAY['買贈', '牙膏', '日用品']
),
(
  '思念寧波風味湯圓平均$7.3/包',
  '思念寧波風味湯圓 $21.9/3包（平均$7.3/包，原價約$16/包），約46折。另外灣仔碼頭湯圓亦有優惠。',
  '惠康 Wellcome',
  (SELECT id FROM categories WHERE name = '超市' LIMIT 1),
  16, 7.3, 54,
  22.2972, 114.1753,
  '2026-09-11', '2026-09-17',
  false,
  ARRAY['湯圓', '中秋', '折扣']
),
(
  '指定韓國產品滿$100賺20x yuu分',
  '購買指定韓國品牌產品（CJ bibigo、不倒翁、農心、真露等）滿$100，即賺20x yuu積分（相等於約10%回贈）。「韓味解鎖」活動至9月17日。',
  '惠康 Wellcome',
  (SELECT id FROM categories WHERE name = '超市' LIMIT 1),
  NULL, NULL, NULL,
  22.3193, 114.1694,
  '2026-09-04', '2026-09-17',
  true,
  ARRAY['韓國', 'yuu分', '會員']
),

-- PARKnSHOP
(
  '易賞錢會員指定產品低至$10',
  '百福鹽滷硬豆腐/濃豆板豆腐 $18/2盒（平均$9）、萊家粒粒威化 $30（原價$47.5）、可口可樂/雪碧/芬達2L $10（原價$15）等會員專享。',
  '百佳 PARKnSHOP',
  (SELECT id FROM categories WHERE name = '超市' LIMIT 1),
  15, 10, 33,
  22.2781, 114.1777,
  '2026-09-11', '2026-09-17',
  true,
  ARRAY['易賞錢', '會員', '低至$10']
),
(
  '買Baker’s Choice月餅滿$258送鮑魚',
  '購買任何Baker’s Choice佳味工房月餅滿$258，即送1罐金御膳蠔皇鮑魚或紅燒瑤柱鮑魚四隻裝（價值約$35）。優惠至9月25日。',
  '百佳 PARKnSHOP',
  (SELECT id FROM categories WHERE name = '超市' LIMIT 1),
  NULL, NULL, NULL,
  22.3081, 114.1712,
  '2026-09-11', '2026-09-25',
  true,
  ARRAY['中秋', '月餅', '買贈']
),
(
  '易賞錢門市滿$150減$8 / 滿$138減$10',
  '易賞錢會員於門市買滿$150即減$8；買滿$138且包含1件SELECT佳之選產品即減$10。可於易賞錢App領取電子券。',
  '百佳 PARKnSHOP',
  (SELECT id FROM categories WHERE name = '超市' LIMIT 1),
  NULL, NULL, NULL,
  22.2832, 114.1551,
  '2026-09-01', '2026-09-30',
  false,
  ARRAY['易賞錢', '滿減', '會員']
);

-- 3. Restaurant / Dining Deals
INSERT INTO deals (
  title,
  description,
  store_name,
  category_id,
  original_price,
  discount_price,
  discount_percentage,
  latitude,
  longitude,
  start_date,
  end_date,
  is_featured,
  tags
) VALUES
-- Chain restaurants
(
  'Pizza Hut 日日買一送一（15款主食）',
  '即日起至9月30日（9月25日除外），多達15款人氣薄餅、意粉、燉飯等主食買一送一，平均每份低至$35起。部分分店週末17:00後不適用。',
  'Pizza Hut 必勝客',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, 35, 50,
  22.2972, 114.1722,
  '2026-09-01', '2026-09-30',
  true,
  ARRAY['買一送一', '薄餅', '限時']
),
(
  '麥當勞App「麥麥勁賞」每日超值餐',
  '至9月13日，App每日輪流推出破底價套餐（例如$20四件脆香雞翼、$25板燒雞腿飽、$10兩個香芋批等），期間選購更享雙倍積分。',
  '麥當勞 McDonald''s',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, 20, NULL,
  22.2810, 114.1550,
  '2026-09-01', '2026-09-13',
  true,
  ARRAY['App優惠', '超值餐', '限時']
),
(
  'KFC「肯！抵DEAL」指定套餐優惠',
  '至9月30日，平日有$36巴辣全雞孖堡、$39四件雞等；週末有買一送一及$88分享桶等優惠。詳情以KFC App及門市為準。',
  'KFC 肯德基',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, 36, NULL,
  22.3193, 114.1694,
  '2026-09-01', '2026-09-30',
  true,
  ARRAY['炸雞', '超值', 'App']
),
(
  '長者$18下午茶（8大連鎖）',
  '第六輪「愛心食肆 賞你惠食」：$18可歎大家樂、美心MX、大快活、太興/敏華、麥當勞、Pizza Hut、KFC、銀龍指定下午茶。9月16日起於長者中心派券，使用期10月1日至11月30日。',
  '大家樂 / 美心 / 大快活 等',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, 18, NULL,
  22.2780, 114.1820,
  '2026-10-01', '2026-11-30',
  true,
  ARRAY['長者', '下午茶', '政府計劃']
),

-- More ordinary / mid-tier & platform deals
(
  '香港餐廳周精選套餐低至7折（300+餐廳）',
  '超過300間參與餐廳（包括很多獨立及中小型餐廳）推出精選午市/晚市套餐，低至7折。午市由約$148起、晚市由約$298起。需經DiningCity或餐廳周網站預訂。',
  '香港餐廳周參與餐廳',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, 148, 30,
  22.2810, 114.1550,
  '2026-08-13', '2026-09-27',
  true,
  ARRAY['餐廳周', '套餐', '7折', '獨立餐廳']
),
(
  'OpenRice 外賣自取滿額減',
  'OpenRice 外賣自取：早上用優惠碼 LUNCH、下午用 DINNER，滿$40即減$5。另有其他季節性優惠碼。適用於全港大量普通餐廳。',
  'OpenRice 合作餐廳',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, NULL, NULL,
  22.3193, 114.1694,
  '2026-09-01', '2026-09-30',
  true,
  ARRAY['外賣自取', 'OpenRice', '普通餐廳']
),
(
  '喰楽 生日正日晚市85折',
  '壽星於生日正日晚市時段（約6-10pm）惠顧可享全單85折；生日當月晚市可享9折。需提前以電話/WhatsApp/IG訂座。',
  '喰楽',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, NULL, 15,
  22.2970, 114.1720,
  '2026-09-01', '2026-12-31',
  false,
  ARRAY['生日優惠', '獨立餐廳', '晚市']
),
(
  'Bistro Bloom 4人同行1人免費',
  '逢星期一至四，惠顧半自助晚餐或精選晚餐，4人同行可享1人免費（以最低價套餐計算）。',
  'Bistro Bloom',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, NULL, 25,
  22.2780, 114.1820,
  '2026-09-01', '2026-12-31',
  false,
  ARRAY['4人1免費', '平日優惠']
),
(
  'Zoku 日式串燒放題（週三）',
  '灣仔 The Hari 酒店 Zoku 餐廳，每逢星期三推出日式串燒+卷物放題，約$398起（已包部分飲品），可加配和牛等升級。',
  'Zoku (The Hari)',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, 398, NULL,
  22.2785, 114.1730,
  '2026-09-01', '2026-12-31',
  false,
  ARRAY['放題', '串燒', '週三']
),
(
  '九龍香格里拉 Café Kool 自助餐買一送一',
  '夏日東瀛主題自助餐，午餐買一送一人均低至約$199起，晚餐買一送一。可經KKday預訂，使用期至9月30日。',
  '九龍香格里拉 Café Kool',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, 199, 50,
  22.3010, 114.1760,
  '2026-09-09', '2026-09-30',
  true,
  ARRAY['自助餐', '買一送一', '酒店']
),
(
  'foodpanda 指定餐廳外送折扣',
  '9月有多個優惠碼：新用戶首單可享高折扣、指定餐廳外送優惠、生活百貨85折等。詳情以foodpanda App最新優惠為準。',
  'foodpanda 合作餐廳',
  (SELECT id FROM categories WHERE name = '飲食' LIMIT 1),
  NULL, NULL, NULL,
  22.3193, 114.1694,
  '2026-09-01', '2026-09-20',
  false,
  ARRAY['外賣', '優惠碼', '外送']
);
