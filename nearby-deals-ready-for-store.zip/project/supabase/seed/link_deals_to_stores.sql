-- ============================================================
-- Optional: Link existing deals to nearest matching store
-- Run AFTER both hk_stores_seed.sql and hk_deals_seed.sql
-- This assigns store_id by matching brand keywords in store_name
-- and picks one representative store (can refine later)
-- ============================================================

-- Wellcome deals → one Wellcome store (Central as default)
UPDATE deals d
SET store_id = s.id
FROM stores s
WHERE d.store_name ILIKE '%惠康%'
  AND s.brand = '惠康 Wellcome'
  AND s.name = '惠康 (中環萬宜大廈)'
  AND d.store_id IS NULL;

-- PARKnSHOP deals
UPDATE deals d
SET store_id = s.id
FROM stores s
WHERE d.store_name ILIKE '%百佳%'
  AND s.brand = '百佳 PARKnSHOP'
  AND s.name = '百佳 (中環國際金融中心)'
  AND d.store_id IS NULL;

-- Pizza Hut
UPDATE deals d
SET store_id = s.id
FROM stores s
WHERE d.store_name ILIKE '%Pizza Hut%' OR d.store_name ILIKE '%必勝客%'
  AND s.brand = 'Pizza Hut 必勝客'
  AND s.name = '必勝客 (尖沙咀)'
  AND d.store_id IS NULL;

-- McDonald's
UPDATE deals d
SET store_id = s.id
FROM stores s
WHERE d.store_name ILIKE '%麥當勞%' OR d.store_name ILIKE '%McDonald%'
  AND s.brand = '麥當勞 McDonald''s'
  AND s.name = '麥當勞 (中環)'
  AND d.store_id IS NULL;

-- KFC
UPDATE deals d
SET store_id = s.id
FROM stores s
WHERE d.store_name ILIKE '%KFC%' OR d.store_name ILIKE '%肯德基%'
  AND s.brand = 'KFC 肯德基'
  AND s.name = 'KFC (旺角)'
  AND d.store_id IS NULL;

-- Quick check
-- SELECT d.title, d.store_name, s.name AS linked_store, s.district
-- FROM deals d
-- LEFT JOIN stores s ON d.store_id = s.id
-- ORDER BY d.created_at DESC;
