import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import { supabase } from '@/lib/supabase';
import { calculateDistanceMeters, isDealActive } from '@/lib/helpers';
import { useDeviceId } from '@/hooks/useDeviceId';
import type { Deal } from '@/types/deals';
import type { LocationCoords } from '@/hooks/useUserLocation';

type FavoritesContextValue = {
  favoriteIds: Set<string>;
  isFavorite: (dealId: string) => boolean;
  toggleFavorite: (dealId: string) => Promise<void>;
  clearAllFavorites: () => Promise<void>;
  loading: boolean;
  deviceId: string | null;
  deviceReady: boolean;
  reload: () => Promise<void>;
};

const FavoritesContext = createContext<FavoritesContextValue | null>(null);

export function FavoritesProvider({ children }: { children: ReactNode }) {
  const { deviceId, ready: deviceReady } = useDeviceId();
  const [favoriteIds, setFavoriteIds] = useState<Set<string>>(new Set());
  const [loading, setLoading] = useState(true);

  const loadFavorites = useCallback(async () => {
    if (!deviceId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('favorite_deals')
      .select('deal_id')
      .eq('device_id', deviceId);

    if (error) {
      setLoading(false);
      return;
    }

    setFavoriteIds(new Set(data?.map((f: { deal_id: string }) => f.deal_id) || []));
    setLoading(false);
  }, [deviceId]);

  useEffect(() => {
    if (!deviceReady || !deviceId) return;
    loadFavorites();
  }, [deviceReady, deviceId, loadFavorites]);

  const toggleFavorite = useCallback(
    async (dealId: string) => {
      if (!deviceId) return;

      const wasFav = favoriteIds.has(dealId);

      // Optimistic update
      setFavoriteIds((prev) => {
        const next = new Set(prev);
        if (wasFav) next.delete(dealId);
        else next.add(dealId);
        return next;
      });

      try {
        if (wasFav) {
          const { error } = await supabase
            .from('favorite_deals')
            .delete()
            .eq('deal_id', dealId)
            .eq('device_id', deviceId);
          if (error) throw error;
        } else {
          const { error } = await supabase
            .from('favorite_deals')
            .insert({ deal_id: dealId, device_id: deviceId });
          if (error) throw error;
        }
      } catch {
        // Rollback on failure
        setFavoriteIds((prev) => {
          const next = new Set(prev);
          if (wasFav) next.add(dealId);
          else next.delete(dealId);
          return next;
        });
      }
    },
    [favoriteIds, deviceId]
  );

  const clearAllFavorites = useCallback(async () => {
    if (!deviceId) return;
    const previous = new Set(favoriteIds);
    setFavoriteIds(new Set());
    try {
      const { error } = await supabase
        .from('favorite_deals')
        .delete()
        .eq('device_id', deviceId);
      if (error) throw error;
    } catch {
      setFavoriteIds(previous);
    }
  }, [deviceId, favoriteIds]);

  const isFavorite = useCallback(
    (dealId: string) => favoriteIds.has(dealId),
    [favoriteIds]
  );

  const value = useMemo(
    () => ({
      favoriteIds,
      isFavorite,
      toggleFavorite,
      clearAllFavorites,
      loading,
      deviceId,
      deviceReady,
      reload: loadFavorites,
    }),
    [
      favoriteIds,
      isFavorite,
      toggleFavorite,
      clearAllFavorites,
      loading,
      deviceId,
      deviceReady,
      loadFavorites,
    ]
  );

  return (
    <FavoritesContext.Provider value={value}>{children}</FavoritesContext.Provider>
  );
}

export function useFavorites() {
  const ctx = useContext(FavoritesContext);
  if (!ctx) {
    throw new Error('useFavorites must be used within FavoritesProvider');
  }
  return ctx;
}

/**
 * Favorite deals with joined deal rows, distances recalculated when coords exist.
 */
export function useFavoriteDeals(userCoords?: LocationCoords | null) {
  const { deviceId, deviceReady } = useFavorites();
  const [rawDeals, setRawDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    if (!deviceId) {
      setLoading(false);
      return;
    }
    setLoading(true);
    const { data, error } = await supabase
      .from('favorite_deals')
      .select('deal_id, deals(*, categories(*))')
      .eq('device_id', deviceId)
      .order('created_at', { ascending: false });

    if (error) {
      setLoading(false);
      return;
    }

    const mapped = (data || [])
      .map((f: { deals: Deal | Deal[] | null }) => {
        if (Array.isArray(f.deals)) return f.deals[0];
        return f.deals;
      })
      .filter((d: Deal | null | undefined): d is Deal => d != null)
      .filter(isDealActive);
    setRawDeals(mapped);
    setLoading(false);
  }, [deviceId]);

  useEffect(() => {
    if (!deviceReady || !deviceId) return;
    load();
  }, [deviceReady, deviceId, load]);

  const deals = useMemo(() => {
    if (!userCoords) return rawDeals;
    return rawDeals.map((deal) => {
      if (deal.latitude == null || deal.longitude == null) {
        return { ...deal, distance_meters: null };
      }
      const meters = calculateDistanceMeters(
        userCoords.latitude,
        userCoords.longitude,
        deal.latitude,
        deal.longitude
      );
      return { ...deal, distance_meters: Math.round(meters) };
    });
  }, [rawDeals, userCoords]);

  return { deals, loading: loading || !deviceReady, reload: load };
}
