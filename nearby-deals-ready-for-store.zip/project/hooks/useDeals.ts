import { useEffect, useState, useCallback, useMemo } from 'react';
import { supabase } from '@/lib/supabase';
import { calculateDistanceMeters, isDealActive, todayDateString } from '@/lib/helpers';
import type { Deal } from '@/types/deals';
import type { LocationCoords } from '@/hooks/useUserLocation';

// Re-export favorites API so existing imports from useDeals still work
export { useFavorites, useFavoriteDeals, FavoritesProvider } from '@/hooks/useFavorites';

/**
 * Loads active deals from Supabase (excludes expired by end_date) and, when
 * user coords are available, overwrites distance_meters with Haversine distance.
 */
export function useDeals(userCoords?: LocationCoords | null) {
  const [rawDeals, setRawDeals] = useState<Deal[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const loadDeals = useCallback(async () => {
    setLoading(true);
    setError(null);
    const today = todayDateString();

    // Server-side: keep rows with no end_date or end_date >= today
    const { data, error: queryError } = await supabase
      .from('deals')
      .select('*, categories(*)')
      .or(`end_date.is.null,end_date.gte.${today}`)
      .order('is_featured', { ascending: false })
      .order('distance_meters', { ascending: true, nullsFirst: false });

    if (queryError) {
      setError('無法載入優惠資料，請稍後再試');
      setLoading(false);
      return;
    }

    // Client-side safety net (timezone / date parsing edge cases)
    const active = ((data as Deal[]) || []).filter(isDealActive);
    setRawDeals(active);
    setLoading(false);
  }, []);

  useEffect(() => {
    loadDeals();
  }, [loadDeals]);

  const deals = useMemo(() => {
    if (!userCoords) {
      return rawDeals;
    }

    return rawDeals.map((deal) => {
      if (deal.latitude == null || deal.longitude == null) {
        return { ...deal, distance_meters: null };
      }
      const meters = calculateDistanceMeters(
        userCoords.latitude,
        userCoords.longitude,
        deal.latitude,
        deal.longitude
      );
      return {
        ...deal,
        distance_meters: Math.round(meters),
      };
    });
  }, [rawDeals, userCoords]);

  return { deals, loading, error, reload: loadDeals };
}
