import { useEffect, useState, useCallback } from 'react';
import { supabase } from '@/lib/supabase';
import type { Category } from '@/types/deals';

/**
 * Loads all categories from Supabase (independent of deals).
 * Used for home page filter chips so categories still show even when
 * a category currently has zero active deals.
 */
export function useCategories() {
  const [categories, setCategories] = useState<Category[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const load = useCallback(async () => {
    setLoading(true);
    setError(null);

    const { data, error: queryError } = await supabase
      .from('categories')
      .select('*')
      .order('name', { ascending: true });

    if (queryError) {
      setError('無法載入分類');
      setLoading(false);
      return;
    }

    setCategories((data as Category[]) || []);
    setLoading(false);
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  return { categories, loading, error, reload: load };
}
