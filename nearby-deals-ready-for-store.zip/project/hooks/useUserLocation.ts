import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useRef,
  useState,
  type ReactNode,
} from 'react';
import { AppState, Platform, type AppStateStatus } from 'react-native';
import * as Location from 'expo-location';

export type LocationCoords = {
  latitude: number;
  longitude: number;
};

export type LocationStatus =
  | 'idle'
  | 'requesting'
  | 'granted'
  | 'denied'
  | 'unavailable'
  | 'error';

type LocationContextValue = {
  coords: LocationCoords | null;
  status: LocationStatus;
  loading: boolean;
  refreshing: boolean;
  errorMessage: string | null;
  lastUpdated: Date | null;
  refresh: () => Promise<LocationCoords | null>;
  hasLocation: boolean;
  isNative: boolean;
};

const LocationContext = createContext<LocationContextValue | null>(null);

/** Min movement (m) / time (ms) before watch delivers a new position */
const WATCH_DISTANCE_M = 40;
const WATCH_TIME_MS = 20_000;

async function fetchOnce(): Promise<{
  coords: LocationCoords | null;
  status: LocationStatus;
  errorMessage: string | null;
}> {
  try {
    const { status: permStatus } = await Location.requestForegroundPermissionsAsync();

    if (permStatus !== 'granted') {
      return {
        coords: null,
        status: 'denied',
        errorMessage: '需要位置權限才能顯示附近距離',
      };
    }

    const position = await Location.getCurrentPositionAsync({
      accuracy: Location.Accuracy.Balanced,
    });

    return {
      coords: {
        latitude: position.coords.latitude,
        longitude: position.coords.longitude,
      },
      status: 'granted',
      errorMessage: null,
    };
  } catch (err) {
    const message = err instanceof Error ? err.message : '無法取得位置';
    const lower = message.toLowerCase();
    const status: LocationStatus =
      lower.includes('unavailable') ||
      lower.includes('disabled') ||
      lower.includes('timeout')
        ? 'unavailable'
        : 'error';
    return { coords: null, status, errorMessage: message };
  }
}

export function LocationProvider({ children }: { children: ReactNode }) {
  const [coords, setCoords] = useState<LocationCoords | null>(null);
  const [status, setStatus] = useState<LocationStatus>('idle');
  const [errorMessage, setErrorMessage] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [refreshing, setRefreshing] = useState(false);
  const [lastUpdated, setLastUpdated] = useState<Date | null>(null);
  const watchSubRef = useRef<Location.LocationSubscription | null>(null);
  const mountedRef = useRef(true);

  const stopWatch = useCallback(() => {
    if (watchSubRef.current) {
      watchSubRef.current.remove();
      watchSubRef.current = null;
    }
  }, []);

  const startWatch = useCallback(async () => {
    stopWatch();
    if (Platform.OS === 'web') return;

    try {
      const { status: perm } = await Location.getForegroundPermissionsAsync();
      if (perm !== 'granted') return;

      watchSubRef.current = await Location.watchPositionAsync(
        {
          accuracy: Location.Accuracy.Balanced,
          distanceInterval: WATCH_DISTANCE_M,
          timeInterval: WATCH_TIME_MS,
        },
        (position) => {
          if (!mountedRef.current) return;
          setCoords({
            latitude: position.coords.latitude,
            longitude: position.coords.longitude,
          });
          setStatus('granted');
          setLastUpdated(new Date());
          setErrorMessage(null);
        }
      );
    } catch {
      // Watch optional — one-shot still works
    }
  }, [stopWatch]);

  const refresh = useCallback(async (): Promise<LocationCoords | null> => {
    setRefreshing(true);
    setErrorMessage(null);
    if (!coords) setLoading(true);
    setStatus('requesting');

    const result = await fetchOnce();
    if (!mountedRef.current) return null;

    setStatus(result.status);
    setErrorMessage(result.errorMessage);
    if (result.coords) {
      setCoords(result.coords);
      setLastUpdated(new Date());
      void startWatch();
    }
    setLoading(false);
    setRefreshing(false);
    return result.coords;
  }, [coords, startWatch]);

  useEffect(() => {
    mountedRef.current = true;
    void (async () => {
      setLoading(true);
      setStatus('requesting');
      const result = await fetchOnce();
      if (!mountedRef.current) return;
      setStatus(result.status);
      setErrorMessage(result.errorMessage);
      if (result.coords) {
        setCoords(result.coords);
        setLastUpdated(new Date());
        await startWatch();
      }
      setLoading(false);
    })();

    return () => {
      mountedRef.current = false;
      stopWatch();
    };
  }, [startWatch, stopWatch]);

  useEffect(() => {
    const onChange = (next: AppStateStatus) => {
      if (next === 'active') {
        void refresh();
      } else {
        stopWatch();
      }
    };
    const sub = AppState.addEventListener('change', onChange);
    return () => sub.remove();
  }, [refresh, stopWatch]);

  const value = useMemo(
    () => ({
      coords,
      status,
      loading,
      refreshing,
      errorMessage,
      lastUpdated,
      refresh,
      hasLocation: coords !== null,
      isNative: Platform.OS !== 'web',
    }),
    [coords, status, loading, refreshing, errorMessage, lastUpdated, refresh]
  );

  return (
    <LocationContext.Provider value={value}>{children}</LocationContext.Provider>
  );
}

/**
 * Shared location (must be under LocationProvider).
 * Continuously updates when the user moves ~40m or every ~20s.
 */
export function useUserLocation() {
  const ctx = useContext(LocationContext);
  if (!ctx) {
    throw new Error('useUserLocation must be used within LocationProvider');
  }
  return ctx;
}
