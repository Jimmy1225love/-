import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';
import AsyncStorage from '@react-native-async-storage/async-storage';
import { getTheme, type Theme } from '@/lib/theme';

const STORAGE_KEY = 'nearby_deals_settings';

export type AppLanguage = 'zh' | 'en';

export type AppSettings = {
  notificationsEnabled: boolean;
  nearbyOnly: boolean;
  darkMode: boolean;
  language: AppLanguage;
};

const DEFAULT_SETTINGS: AppSettings = {
  notificationsEnabled: true,
  nearbyOnly: false,
  darkMode: false,
  language: 'zh',
};

/** Nearby-only radius in meters (matches settings description "1 公里內") */
export const NEARBY_ONLY_METERS = 1000;

type SettingsContextValue = AppSettings & {
  theme: Theme;
  ready: boolean;
  setNotificationsEnabled: (v: boolean) => void;
  setNearbyOnly: (v: boolean) => void;
  setDarkMode: (v: boolean) => void;
  setLanguage: (v: AppLanguage) => void;
  toggleLanguage: () => void;
};

const SettingsContext = createContext<SettingsContextValue | null>(null);

async function loadSettings(): Promise<AppSettings> {
  try {
    const raw = await AsyncStorage.getItem(STORAGE_KEY);
    if (!raw) return { ...DEFAULT_SETTINGS };
    const parsed = JSON.parse(raw) as Partial<AppSettings>;
    return {
      notificationsEnabled:
        typeof parsed.notificationsEnabled === 'boolean'
          ? parsed.notificationsEnabled
          : DEFAULT_SETTINGS.notificationsEnabled,
      nearbyOnly:
        typeof parsed.nearbyOnly === 'boolean'
          ? parsed.nearbyOnly
          : DEFAULT_SETTINGS.nearbyOnly,
      darkMode:
        typeof parsed.darkMode === 'boolean'
          ? parsed.darkMode
          : DEFAULT_SETTINGS.darkMode,
      language: parsed.language === 'en' || parsed.language === 'zh'
        ? parsed.language
        : DEFAULT_SETTINGS.language,
    };
  } catch {
    return { ...DEFAULT_SETTINGS };
  }
}

async function saveSettings(next: AppSettings): Promise<void> {
  try {
    await AsyncStorage.setItem(STORAGE_KEY, JSON.stringify(next));
  } catch {
    // ignore persistence errors
  }
}

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [settings, setSettings] = useState<AppSettings>(DEFAULT_SETTINGS);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    let cancelled = false;
    (async () => {
      const loaded = await loadSettings();
      if (!cancelled) {
        setSettings(loaded);
        setReady(true);
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  const update = useCallback((patch: Partial<AppSettings>) => {
    setSettings((prev) => {
      const next = { ...prev, ...patch };
      void saveSettings(next);
      return next;
    });
  }, []);

  const setNotificationsEnabled = useCallback(
    (v: boolean) => update({ notificationsEnabled: v }),
    [update]
  );
  const setNearbyOnly = useCallback(
    (v: boolean) => update({ nearbyOnly: v }),
    [update]
  );
  const setDarkMode = useCallback(
    (v: boolean) => update({ darkMode: v }),
    [update]
  );
  const setLanguage = useCallback(
    (v: AppLanguage) => update({ language: v }),
    [update]
  );
  const toggleLanguage = useCallback(() => {
    setSettings((prev) => {
      const next = {
        ...prev,
        language: (prev.language === 'zh' ? 'en' : 'zh') as AppLanguage,
      };
      void saveSettings(next);
      return next;
    });
  }, []);

  const theme = useMemo(
    () => getTheme(settings.darkMode),
    [settings.darkMode]
  );

  const value = useMemo(
    () => ({
      ...settings,
      theme,
      ready,
      setNotificationsEnabled,
      setNearbyOnly,
      setDarkMode,
      setLanguage,
      toggleLanguage,
    }),
    [
      settings,
      theme,
      ready,
      setNotificationsEnabled,
      setNearbyOnly,
      setDarkMode,
      setLanguage,
      toggleLanguage,
    ]
  );

  return (
    <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>
  );
}

export function useSettings() {
  const ctx = useContext(SettingsContext);
  if (!ctx) {
    throw new Error('useSettings must be used within SettingsProvider');
  }
  return ctx;
}

/** Simple labels for settings / shared UI based on language */
export function useLabels() {
  const { language } = useSettings();
  return language === 'en' ? labelsEn : labelsZh;
}

const labelsZh = {
  settings: '設定',
  settingsSubtitle: '管理你的偏好與收藏',
  notifications: '通知',
  pushDeals: '優惠推播',
  pushDealsDesc: '附近有新優惠時通知你',
  nearbyOnly: '只顯示附近優惠',
  nearbyOnlyDesc: '僅顯示 1 公里內的優惠',
  appearance: '外觀',
  darkMode: '深色模式',
  darkModeDesc: '使用深色主題',
  language: '語言',
  data: '資料管理',
  favorites: '我的收藏',
  clearFavorites: '清除所有收藏',
  clearFavoritesDesc: '無法復原此操作',
  about: '關於',
  version: '應用版本',
  dealCount: '優惠總數',
  dealCountSuffix: '個進行中的優惠',
  aboutApp: '關於附近優惠',
  aboutAppDesc: '自動尋找你周圍的連鎖超市與餐廳優惠',
  appName: '附近優惠 Nearby Deals',
};

const labelsEn = {
  settings: 'Settings',
  settingsSubtitle: 'Manage preferences and favorites',
  notifications: 'Notifications',
  pushDeals: 'Deal alerts',
  pushDealsDesc: 'Notify when new deals are nearby',
  nearbyOnly: 'Nearby only',
  nearbyOnlyDesc: 'Show deals within 1 km only',
  appearance: 'Appearance',
  darkMode: 'Dark mode',
  darkModeDesc: 'Use dark theme',
  language: 'Language',
  data: 'Data',
  favorites: 'My favorites',
  clearFavorites: 'Clear all favorites',
  clearFavoritesDesc: 'This cannot be undone',
  about: 'About',
  version: 'App version',
  dealCount: 'Total deals',
  dealCountSuffix: 'active deals',
  aboutApp: 'About Nearby Deals',
  aboutAppDesc: 'Find supermarket and restaurant deals around you',
  appName: 'Nearby Deals',
};
