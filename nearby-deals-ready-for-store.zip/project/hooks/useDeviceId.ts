import { useEffect, useState } from 'react';
import { getOrCreateDeviceId, getCachedDeviceId } from '@/lib/deviceId';

/**
 * Resolves the stable anonymous device id used for favorites.
 * `ready` is false until the first storage read completes.
 */
export function useDeviceId() {
  const [deviceId, setDeviceId] = useState<string | null>(() => getCachedDeviceId());
  const [ready, setReady] = useState(() => getCachedDeviceId() != null);

  useEffect(() => {
    let cancelled = false;
    getOrCreateDeviceId().then((id) => {
      if (!cancelled) {
        setDeviceId(id);
        setReady(true);
      }
    });
    return () => {
      cancelled = true;
    };
  }, []);

  return { deviceId, ready };
}
