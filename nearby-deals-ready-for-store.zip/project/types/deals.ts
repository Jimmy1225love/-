export interface Category {
  id: string;
  name: string;
  icon_name: string;
  color: string;
  created_at: string;
}

export interface Deal {
  id: string;
  title: string;
  description: string | null;
  store_name: string;
  category_id: string | null;
  original_price: number | null;
  discount_price: number | null;
  discount_percentage: number | null;
  image_url: string | null;
  latitude: number | null;
  longitude: number | null;
  distance_meters: number | null;
  start_date: string | null;
  end_date: string | null;
  is_featured: boolean;
  tags: string[];
  created_at: string;
  categories?: Category;
}

export interface FavoriteDeal {
  id: string;
  deal_id: string;
  device_id: string;
  created_at: string;
}
