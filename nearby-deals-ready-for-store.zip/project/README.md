# 附近優惠 (Nearby Deals HK)

香港超市與餐廳優惠 App — 依你的位置找出附近著數。

Built with **Expo (React Native)** + **Supabase**.

---

## Features

- 附近優惠列表（距離、折扣、到期日排序）
- 分類篩選（超市、飲食、便利店…）
- 搜尋店名 / 標籤
- 地圖顯示
- 匿名收藏（device_id，無需登入）
- 香港真實優惠 seed + 分店座標

---

## Tech stack

| Layer | Tech |
|-------|------|
| App | Expo Router, TypeScript |
| Backend | Supabase (Postgres + RLS) |
| Location | expo-location + Haversine |
| Maps | react-native-maps |

---

## Project structure

```
project/
├── app/                  # Screens (Expo Router)
│   ├── (tabs)/           # Home, Map, Favorites, Settings
│   └── deal/[id].tsx     # Deal detail
├── components/           # DealCard, markers, empty states
├── hooks/                # useDeals, useCategories, useFavorites…
├── lib/                  # supabase client, helpers, theme
├── types/                # Deal, Category types
├── supabase/
│   ├── migrations/       # Schema (deals, categories, stores)
│   └── seed/             # HK deals + stores SQL
└── docs/                 # Privacy, terms, store listing, launch checklist
```

---

## Setup

### 1. Install

```bash
cd project
npm install
```

### 2. Environment

Copy `.env` and set your Supabase keys:

```env
EXPO_PUBLIC_SUPABASE_URL=https://xxxx.supabase.co
EXPO_PUBLIC_SUPABASE_ANON_KEY=your-anon-key
```

### 3. Database

In **Supabase SQL Editor**, run in order:

1. `supabase/migrations/20260905165314_create_deals_tables.sql`
2. `supabase/migrations/20260912010000_create_stores_table.sql`
3. `supabase/seed/hk_stores_seed.sql`
4. `supabase/seed/hk_deals_seed.sql`
5. `supabase/seed/link_deals_to_stores.sql` (optional)

### 4. Run

```bash
npx expo start
```

---

## App config (before store release)

Edit `app.json`:

| Field | What to set |
|-------|-------------|
| `expo.name` | 附近優惠 (already set) |
| `ios.bundleIdentifier` | e.g. `com.yourname.nearbydeals` |
| `android.package` | Same as bundle ID |
| `extra.privacyPolicyUrl` | Your HTTPS privacy page |
| `extra.termsUrl` | Your HTTPS terms page |

Also update the privacy/terms URLs in `app/(tabs)/settings.tsx`.

See **`docs/README_LAUNCH.md`** for the full launch guide.

---

## Docs

| File | Description |
|------|-------------|
| [docs/PRIVACY_POLICY.md](docs/PRIVACY_POLICY.md) | Privacy policy (host on HTTPS) |
| [docs/TERMS_OF_SERVICE.md](docs/TERMS_OF_SERVICE.md) | Terms of service |
| [docs/STORE_LISTING.md](docs/STORE_LISTING.md) | App Store / Play listing copy |
| [docs/SUBMISSION_CHECKLIST.md](docs/SUBMISSION_CHECKLIST.md) | Pre-submit checklist + EAS |
| [docs/DATA_UPDATE_GUIDE.md](docs/DATA_UPDATE_GUIDE.md) | How to refresh deal data |
| [docs/README_LAUNCH.md](docs/README_LAUNCH.md) | Launch overview |

---

## Store short description

```
香港超市餐廳優惠，依距離找附近著數。地圖、收藏、分類篩選。
```

---

## License

Private / your own use unless otherwise stated.
