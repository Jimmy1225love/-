import { ActivityIndicator, StyleSheet, Text, View } from 'react-native';
import { theme } from '@/lib/theme';

interface LoadingStateProps {
  message?: string;
}

export function LoadingState({ message = '載入中...' }: LoadingStateProps) {
  return (
    <View style={styles.container}>
      <ActivityIndicator size="large" color={theme.primary} />
      <Text style={styles.text}>{message}</Text>
    </View>
  );
}

interface ErrorStateProps {
  message: string;
  onRetry?: () => void;
  retryLabel?: string;
}

export function ErrorState({ message, onRetry, retryLabel = '重新載入' }: ErrorStateProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.errorIcon}>!</Text>
      <Text style={styles.errorText}>{message}</Text>
      {onRetry && (
        <Pressable style={styles.retryButton} onPress={onRetry}>
          <Text style={styles.retryText}>{retryLabel}</Text>
        </Pressable>
      )}
    </View>
  );
}

import { Pressable } from 'react-native';

interface EmptyStateProps {
  icon?: string;
  title: string;
  subtitle?: string;
}

export function EmptyState({ title, subtitle }: EmptyStateProps) {
  return (
    <View style={styles.container}>
      <Text style={styles.emptyTitle}>{title}</Text>
      {subtitle && <Text style={styles.emptySubtitle}>{subtitle}</Text>}
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
    padding: 32,
    minHeight: 300,
  },
  text: {
    marginTop: 12,
    fontSize: 14,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
  },
  errorIcon: {
    fontSize: 48,
    color: theme.error,
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
    marginBottom: 8,
  },
  errorText: {
    fontSize: 15,
    color: theme.textSecondary,
    textAlign: 'center',
    fontFamily: 'NotoSansTC-Regular',
    lineHeight: 22,
  },
  retryButton: {
    marginTop: 16,
    backgroundColor: theme.primary,
    paddingHorizontal: 24,
    paddingVertical: 10,
    borderRadius: 10,
  },
  retryText: {
    color: '#FFFFFF',
    fontSize: 14,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  emptyTitle: {
    fontSize: 18,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-SemiBold',
    fontWeight: '600',
    textAlign: 'center',
    marginBottom: 8,
  },
  emptySubtitle: {
    fontSize: 14,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
    textAlign: 'center',
    lineHeight: 22,
  },
});
