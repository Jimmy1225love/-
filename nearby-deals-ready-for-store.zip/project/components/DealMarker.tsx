import { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Marker } from 'react-native-maps';
import { Store, Coffee, ShoppingCart, UtensilsCrossed, Cake, Tag } from 'lucide-react-native';
import type { LucideIcon } from 'lucide-react-native';
import type { Deal } from '@/types/deals';
import { theme } from '@/lib/theme';

const iconMap: Record<string, LucideIcon> = {
  超市: ShoppingCart,
  餐廳: UtensilsCrossed,
  咖啡: Coffee,
  便利商店: Store,
  甜點: Cake,
};

interface DealMarkerProps {
  deal: Deal;
  selected: boolean;
  onPress: (deal: Deal) => void;
}

function DealMarkerComponent({ deal, selected, onPress }: DealMarkerProps) {
  if (deal.latitude == null || deal.longitude == null) return null;

  const color = selected ? theme.accent : deal.categories?.color || theme.primary;
  const Icon = (deal.categories && iconMap[deal.categories.name]) || Tag;
  const pct =
    deal.discount_percentage != null && deal.discount_percentage > 0
      ? Math.round(deal.discount_percentage)
      : null;

  return (
    <Marker
      coordinate={{
        latitude: deal.latitude,
        longitude: deal.longitude,
      }}
      tracksViewChanges={false}
      onPress={(e) => {
        e.stopPropagation();
        onPress(deal);
      }}
      anchor={{ x: 0.5, y: 1 }}
    >
      <View style={styles.wrap}>
        {pct != null && (
          <View style={[styles.badge, selected && styles.badgeSelected]}>
            <Text style={styles.badgeText}>{pct}%</Text>
          </View>
        )}
        <View
          style={[
            styles.pin,
            {
              backgroundColor: color,
              borderColor: selected ? theme.accent : '#FFFFFF',
              transform: [{ scale: selected ? 1.15 : 1 }],
            },
          ]}
        >
          <Icon size={selected ? 16 : 14} color="#FFFFFF" strokeWidth={2.5} />
        </View>
        <View style={[styles.tail, { borderTopColor: color }]} />
      </View>
    </Marker>
  );
}

export const DealMarker = memo(DealMarkerComponent);

const styles = StyleSheet.create({
  wrap: {
    alignItems: 'center',
  },
  badge: {
    backgroundColor: theme.error,
    paddingHorizontal: 5,
    paddingVertical: 1,
    borderRadius: 8,
    marginBottom: 2,
    borderWidth: 1.5,
    borderColor: '#FFFFFF',
  },
  badgeSelected: {
    backgroundColor: theme.accent,
  },
  badgeText: {
    color: '#FFFFFF',
    fontSize: 10,
    fontWeight: '700',
    fontFamily: 'NotoSansTC-Bold',
  },
  pin: {
    width: 34,
    height: 34,
    borderRadius: 17,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2.5,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.25,
    shadowRadius: 3,
    elevation: 4,
  },
  tail: {
    width: 0,
    height: 0,
    borderLeftWidth: 6,
    borderRightWidth: 6,
    borderTopWidth: 8,
    borderLeftColor: 'transparent',
    borderRightColor: 'transparent',
    marginTop: -1,
  },
});
