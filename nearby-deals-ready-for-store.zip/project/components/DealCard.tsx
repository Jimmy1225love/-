import { Pressable, StyleSheet, Text, View } from 'react-native';
import { Heart, MapPin, Tag } from 'lucide-react-native';
import type { Deal } from '@/types/deals';
import { theme } from '@/lib/theme';
import { formatPrice, formatDistance, urgencyLabel } from '@/lib/helpers';

interface DealCardProps {
  deal: Deal;
  isFavorite: boolean;
  onToggleFavorite: (dealId: string) => void;
  onPress: (deal: Deal) => void;
  compact?: boolean;
}

export function DealCard({
  deal,
  isFavorite,
  onToggleFavorite,
  onPress,
  compact = false,
}: DealCardProps) {
  const urgency = urgencyLabel(deal.end_date);
  const hasDiscount =
    deal.original_price !== null &&
    deal.discount_price !== null &&
    deal.original_price > deal.discount_price;

  return (
    <Pressable
      style={({ pressed }) => [styles.card, pressed && styles.cardPressed]}
      onPress={() => onPress(deal)}
    >
      <View style={styles.headerRow}>
        <View style={styles.storeBadge}>
          <Tag size={12} color={theme.primary} strokeWidth={2.5} />
          <Text style={styles.storeName} numberOfLines={1}>
            {deal.store_name}
          </Text>
        </View>
        <Pressable
          hitSlop={{ top: 10, bottom: 10, left: 10, right: 10 }}
          onPress={() => onToggleFavorite(deal.id)}
        >
          <Heart
            size={22}
            color={isFavorite ? theme.error : theme.textTertiary}
            fill={isFavorite ? theme.error : 'transparent'}
            strokeWidth={2}
          />
        </Pressable>
      </View>

      <Text style={styles.title} numberOfLines={compact ? 1 : 2}>
        {deal.title}
      </Text>

      {!compact && deal.description && (
        <Text style={styles.description} numberOfLines={2}>
          {deal.description}
        </Text>
      )}

      <View style={styles.footerRow}>
        <View style={styles.priceRow}>
          {hasDiscount && (
            <Text style={styles.originalPrice}>{formatPrice(deal.original_price)}</Text>
          )}
          {deal.discount_price !== null && (
            <Text style={styles.discountPrice}>{formatPrice(deal.discount_price)}</Text>
          )}
          {deal.discount_percentage !== null && deal.discount_percentage > 0 && (
            <View style={styles.discountBadge}>
              <Text style={styles.discountBadgeText}>{deal.discount_percentage}% OFF</Text>
            </View>
          )}
        </View>

        <View style={styles.metaRow}>
          {deal.distance_meters !== null && (
            <View style={styles.distancePill}>
              <MapPin size={11} color={theme.textSecondary} strokeWidth={2.5} />
              <Text style={styles.distanceText}>{formatDistance(deal.distance_meters)}</Text>
            </View>
          )}
          {urgency && (
            <View style={[styles.urgencyPill, { backgroundColor: `${urgency.color}15` }]}>
              <Text style={[styles.urgencyText, { color: urgency.color }]}>{urgency.label}</Text>
            </View>
          )}
        </View>
      </View>

      {deal.tags && deal.tags.length > 0 && !compact && (
        <View style={styles.tagsRow}>
          {deal.tags.slice(0, 3).map((tag, i) => (
            <View key={i} style={styles.tagPill}>
              <Text style={styles.tagText}>{tag}</Text>
            </View>
          ))}
        </View>
      )}
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    backgroundColor: theme.cardBg,
    borderRadius: 16,
    padding: 16,
    marginBottom: 12,
    shadowColor: theme.shadow,
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 1,
    shadowRadius: 8,
    elevation: 3,
    borderWidth: 1,
    borderColor: theme.borderLight,
  },
  cardPressed: {
    transform: [{ scale: 0.98 }],
    opacity: 0.9,
  },
  headerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: 8,
  },
  storeBadge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 4,
    backgroundColor: theme.primaryLight,
    paddingHorizontal: 8,
    paddingVertical: 4,
    borderRadius: 8,
    flexShrink: 1,
  },
  storeName: {
    fontSize: 12,
    color: theme.primary,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  title: {
    fontSize: 16,
    color: theme.textPrimary,
    fontFamily: 'NotoSansTC-SemiBold',
    fontWeight: '600',
    lineHeight: 24,
    marginBottom: 4,
  },
  description: {
    fontSize: 13,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
    lineHeight: 20,
    marginBottom: 10,
  },
  footerRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'flex-end',
    flexWrap: 'wrap',
    gap: 8,
  },
  priceRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  originalPrice: {
    fontSize: 13,
    color: theme.textTertiary,
    fontFamily: 'NotoSansTC-Regular',
    textDecorationLine: 'line-through',
  },
  discountPrice: {
    fontSize: 20,
    color: theme.error,
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
  },
  discountBadge: {
    backgroundColor: theme.errorLight,
    paddingHorizontal: 6,
    paddingVertical: 2,
    borderRadius: 6,
  },
  discountBadgeText: {
    fontSize: 11,
    color: theme.error,
    fontFamily: 'NotoSansTC-Bold',
    fontWeight: '700',
  },
  metaRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
  },
  distancePill: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 3,
    backgroundColor: theme.borderLight,
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 8,
  },
  distanceText: {
    fontSize: 11,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
  },
  urgencyPill: {
    paddingHorizontal: 7,
    paddingVertical: 3,
    borderRadius: 8,
  },
  urgencyText: {
    fontSize: 11,
    fontFamily: 'NotoSansTC-Medium',
    fontWeight: '500',
  },
  tagsRow: {
    flexDirection: 'row',
    gap: 6,
    marginTop: 10,
  },
  tagPill: {
    backgroundColor: theme.borderLight,
    paddingHorizontal: 8,
    paddingVertical: 3,
    borderRadius: 8,
  },
  tagText: {
    fontSize: 11,
    color: theme.textSecondary,
    fontFamily: 'NotoSansTC-Regular',
  },
});
